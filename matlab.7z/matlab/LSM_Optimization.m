close all;
clear all;

run_modes = [string('Regular'), string('Twiddle'), string('pattern_search'), string('anneal'), string('BruteForce'), string('GA')];
run_mode = char(run_modes(1)); % The run mode can be Regular, Twiddle, fmincon, anneal, BruteForce and GA

% x = [68.346	-22.959	77.447	-24.301	-0.96614	9.5529	0.079965	0.81314	3.7562	3.58	3.8	23.913];
x = [68.346	-22.959	77.447	-24.301	-0.2	9.5529	0.079965	0.81314	10	10	3.8	23.913];

switch run_mode
    case 'Regular'
%         materials = modify_material(x, materials);
        server_path = strcat('./Results/', date, '_', run_mode, '_result.csv');
        cost = lsme3d_cost(x, server_path);
    case 'Twiddle'
        server_path = strcat('./Results/', date, '_', run_mode, '_result.csv');
        delete(server_path)
        best_cost = twiddle_fun(x, server_path);
        
    case 'BruteForce'
%         server_path = strcat('/pscratch/fecheng/', date, '_', run_mode, 'twidding_result.csv');
        server_path = strcat('./Results/', date, '_', run_mode, '_result.csv');
        delete(server_path)
        index1 = 1;
        index2 = 5;
        index3 = 6;
        
        for i = -15:3:15
%             for j = -1:0.2:1
%                 for k =-range3/2:range3/5:range3/2
                    x1 = x;
                    x1(index1) = x(index1) + i;
%                     x1(index2) = x(index2) + j;
%                     x1(index3) = x(index3) + k;
                    new_cost = lsme3d_cost(x, server_path);
%                 end
%             end
        end
        
    case 'GA'
        server_path = strcat('./Results/', date, '_', run_mode, '_result.csv');
        %         server_path = strcat(gauge_set,'_', run_mode,'_', record_name);
        delete(server_path)
        fun = @(x)lsme3d_cost(x, server_path);
        A = [];
        b = [];
        Aeq = [];
        beq = [];
        lb = [];
        ub = [];
        n = numel(x);
        % nonlcon = [];
        % options = optimoptions('ga','PlotFcn', @gaplotbestf);
        [x,fval,exitflag,output] = ga(fun,n,A,b,Aeq,beq,lb,ub);
        
    case 'pattern_search'
        server_path = strcat('./Results/', date, '_', run_mode, '_result.csv');
        delete(server_path)
%         materials = modify_material(x, materials);
        fun = @(x)lsme3d_cost(x, server_path);
        best_x = patternsearch(fun, x);
        
    case 'anneal'
        view_etch = 0;
        %         server_path = strcat(gauge_set,'_', run_mode,'_',record_name);
        server_path = strcat('/pscratch/fecheng/', gauge_set,'_', run_mode,'_',record_name);
        delete(server_path);
        fun = @(x)lsme3d_cost(x, server_path);
        [x, fval, exitflag, output] = simulannealbnd(fun, x,lb, ub);
        
    otherwise
        disp('Choose the right mode');
end

function old_cost = twiddle_fun(para, server_path)
dp =0.05*para;                            % define the learning step size
% materials = modify_material(para, materials);
old_cost = lsme3d_cost(para, server_path);
iteration_cnt = 1;
iteration_limit = 5000;
while sum(dp(:)) > 0.0005 &&  iteration_cnt <= iteration_limit
    for i = 1:length(dp)
        para(i) = para(i) + dp(i);
        new_cost = lsme3d_cost(para, server_path);        
        iteration_cnt = iteration_cnt + 1;
        fprintf('Current iteration: %s \n', num2str(iteration_cnt));
        if iteration_cnt >= iteration_limit
            break;
        end
        if new_cost < old_cost
            old_cost = new_cost;
            dp(i) = 1.1*dp(i);
        else
            para(i) = para(i) - 2*dp(i);
            new_cost = lsme3d_cost(para, server_path);
            iteration_cnt = iteration_cnt + 1;
            fprintf('Current iteration: %s \n', num2str(iteration_cnt));
            if new_cost < old_cost
                old_cost = new_cost;
                dp(i) = 1.1*dp(i);
            else
                para(i) = para(i) + dp(i);
                dp(i) = 0.9*dp(i);
            end
            if iteration_cnt >= iteration_limit
                break;
            end
        end
    end
    fprintf('Best cost: %.2f nm2 \n', old_cost);
end
end
