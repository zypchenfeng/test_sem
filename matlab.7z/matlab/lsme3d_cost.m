function [cost] = lsme3d_cost(paras, server_path)


% x = [7.619	39.83	169.15	3.3693	36.298	212.89	20.926	11.596];  % paras(1:8);
% y = paras(9:end);

x = [7.619	39.83	169.15	3.3693	36.298	212.89	20.926	11.596]; 
y = paras;

enable_regenerate_gauges = 0;
if enable_regenerate_gauges
    %% generating gauges
    commandStr = 'python ./stacks/create_etch_input_from_cutline2.py';
%     equation1 = ' -s "90 + 28.51276 + (-1.268928/0.02656917)*(1 - 2.7183**(-0.02656917*max(30, resist_cd))) - 0.05*min(200,trench_cd) + 5"';
%     equation = [' -s "80 + 28.51276 + ', num2str(x(1)), ' + (-', num2str(x(7)),'/', num2str(x(2)), ...
%         ')*(1 - ', num2str(x(6)), '**(-', num2str(x(2)), '*max(', num2str(x(3)), ', resist_cd))) -', num2str(x(4)), ...
%         '*min(', num2str(x(5)), ',trench_cd)"'];
    equation = [' -s "60 + ', num2str(x(7)), ' - ', num2str(x(1)), ' * min(1, (trench_cd - ', num2str(x(2)), ') / (' , ...
        num2str(x(3)), ' - ', num2str(x(2)), ')) - ', num2str(x(4)), ' * min(1, (resist_cd - ', ...
        num2str(x(5)), ') / (' , num2str(x(6)), ' - ', num2str(x(5)), ')) + (trench_cd > 500)*', num2str(x(8)), ...
        '"'];
    [status, ~] = system(strcat(commandStr, equation));
    if status==0
%         fprintf('squared result is %d\n',str2double(commandOut));
        fprintf('Gauge regeneration done\n');
    end
end
%% Simulation settings
inputgds_dir = './stacks/work1/';
inputgds = dir(strcat(inputgds_dir, '*.input'));
inputMaterials = './stacks/materials8.dat';   % filename of the input stack
materials = mask.loadMaterials(inputMaterials);
materials = modify_material(y, materials);
% server_path = strcat('./Results/', date, '_optimization_result.csv');

% Etch source distributions
% Note: the angle where the Gaussian is centered is defined as seen from
% the observer (a 180deg difference in phi w.r.t. the angle seen from the source)
sourceSettings.ion.standardDeviation = 4.7827 ;          % the standard deviation (=1*sigma) of ion angular distribution
sourceSettings.ion.theta0 = 0 ;                     % the theta angle identifying the center of the distribution
sourceSettings.ion.phi0 = 0 ;                       % the phi angle identifying the center of the distribution
sourceSettings.neutral.standardDeviation = y(12) ;
sourceSettings.neutral.theta0 = 0 ;
sourceSettings.neutral.phi0 = 0 ;
sourceSettings.deposition.standardDeviation = 15.171 ;
sourceSettings.deposition.theta0 = 0 ;
sourceSettings.deposition.phi0 = 0 ;
% materials = mask.loadMaterials(inputMaterials);

flag_2D = true ;    % if true forces 2D simulation (the stack is considered invariant along the y direction)

% Time step settings
tMax = 5 ;     % Total simulation time (in seconds)
t0 = 0.8;
t_strip = 0.5;
controlByTime = true;
stepTime = [0, 0.9, 3.04, 4.4, tMax, tMax+t_strip] + t0;
tMax = tMax + t0 + t_strip;

% Resolution settings
spatialResolution = 2 ;         % Arbitrary units, coherent with the stack representation (typically nm)

% results settings
save_gif = false ;          % set to true for storing a gif of the time evolution
results_folder = './Results/' ;  % Where to save results (gif animations)
Individual_gauge_path = strcat(results_folder, date, '_LSM_E3D.csv');

data_store = {'Index,','Gauge_Name,','type,', 'tone_sgn,', 'wafer_CD,', 'cost_wt,', 'EEB_CD,', 'ADIModelCD,', ...
        'ILS,', 'LSM_CD,', 'LSM_Error,', 'LSM_MSE,'};
    
% mse cost calculation
cost = 0;

tic
% for i = [size(inputgds, 1)-5, size(inputgds, 1)-4] % [randi(size(inputgds, 1)) , randi(size(inputgds, 1))]
% parfor i = [1086:1089]
for i = 1077
% parfor i = 1:size(inputgds, 1)    % if change to parfor, then capable of parallel computation
    inputStack = strcat(inputgds_dir, inputgds(i).name);   % filename of the input stack    
    
    %% Run etch simulation
    if controlByTime
        [~,~,~,~, single_gauge_result] = levelSet.LSM_Etch3D(inputStack, materials, spatialResolution, ...
            sourceSettings, tMax, results_folder, flag_2D, save_gif, stepTime, y(7), y(8)) ;
    else
        [~,~,~,~, single_gauge_result] = levelSet.LSM_Etch3D(inputStack, materials, spatialResolution, ...
            sourceSettings, tMax, results_folder, flag_2D, save_gif, y(7), y(8)) ;
    end
    data_store = [data_store; [strcat(num2str(i), ','), single_gauge_result]];
end
if size(data_store, 1) > 1
    for i = 2:size(data_store, 1)
    	cost = cost + str2double(strip(data_store{i, end}, ','));
    end
    cost = sqrt(cost/(size(data_store, 1)-1));
    fprintf('Current cost is: %.2f nm\n', cost);
end

%% saving individual gauge result
empt = [];
csvwrite(Individual_gauge_path, empt);
fid = fopen(Individual_gauge_path, 'w');
fprintf(fid, '%s', data_store{1, :});
if size(data_store, 1) > 1
    for i = 2:size(data_store, 1)
     fprintf(fid, '\n');
     fprintf(fid, '%s', data_store{i, :});
    end
end
fclose(fid);
t = toc;
fprintf('This iteration run time is %.1f seconds\n', t);
record1 = [cost, paras];
dlmwrite(server_path, record1, '-append','newline','pc');
end

function materials = modify_material(x, materials)
    m = 3;                                      % m is the CD control step
    materials{2}.etchRateV_i(m) = x(1);
    materials{2}.etchRateV_d(m) = x(2);
    materials{2}.etchRateV_i(m+1) = x(3);
    materials{2}.etchRateV_d(m+1) = x(4);
    for i = 1:length(materials)
        materials{i}.etchRateH_d(2:5) = x(5);
    end        
    n = 8;
    materials{2}.etchRateV_n(2) = x(n + 1);
    materials{2}.etchRateV_n(3) = x(n + 2);
    materials{2}.etchRateV_n(4) = x(n + 3);
end
