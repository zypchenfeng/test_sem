function [x,y,z] = closestSurfacePoint(SDF,F,X,Y,Z,Nx,Ny,Nz,origin,IDX)

maxiter = 10 ;
shooting_correction = .001 ;
d0 = 0.005*(X(2)-X(1)) ;

if nargin<10
    if size(X,2)==1
        Fq = F(origin(:,1),origin(:,3)) ;
    else
        Fq = F(origin(:,1),origin(:,2),origin(:,3)) ;
    end
else
    Fq = SDF(IDX) ;
end

P = origin ;

iter = 0 ;
while ( any(abs(Fq)>d0) ) && iter<maxiter
    iter = iter + 1;
    
    % Overshoot below interface, undershoot above
    below = (abs(Fq)>d0) & (Fq>=0) ;
    above = (abs(Fq)>d0) & (Fq<0) ;

    % Move one single step in the direction of the gradient
    t = Fq(below) * (1+shooting_correction) ;
    if ~isempty(t)
        if isempty(Ny.Values)
            normal = [  Nx(P(below,1),P(below,3)), ...
                        zeros(numel(t),1), ...
                        Nz(P(below,1),P(below,3)) ] ;
        else
            normal = [  Nx(P(below,1),P(below,2),P(below,3)), ...
                        Ny(P(below,1),P(below,2),P(below,3)), ...
                        Nz(P(below,1),P(below,2),P(below,3)) ] ;
        end
        P(below,:) = P(below,:) - bsxfun(@times,t,normal) ;
    end
    t = Fq(above) * (1-shooting_correction) ;
    if ~isempty(t)
        if isempty(Ny.Values)
            normal = [  Nx(P(above,1),P(above,3)), ...
                        zeros(numel(t),1), ...
                        Nz(P(above,1),P(above,3)) ] ;
        else
            normal = [  Nx(P(above,1),P(above,2),P(above,3)), ...
                        Ny(P(above,1),P(above,2),P(above,3)), ...
                        Nz(P(above,1),P(above,2),P(above,3)) ] ;
        end
        P(above,:) = P(above,:) - bsxfun(@times,t,normal) ;
    end
    
    % Compute new distance
    if size(X,2)==1
        Fq = F(P(:,1),P(:,3)) ;
    else
        Fq = F(P(:,1),P(:,2),P(:,3)) ;
    end 
%     shooting_correction = shooting_correction * 2 ;
    
end

x = P(:,1) ;
y = P(:,2) ;
z = P(:,3) ;

end