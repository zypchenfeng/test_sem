function Phi = initSDF(X,Y,Z,masks)

Phi = -Z ;

for iMask = 1: numel(masks)
    thisMask = masks{iMask} ;
    Phi = max( Phi, levelSet.computeDistanceFunction(X,Y,Z,thisMask) ) ;
end

% % Use levelSet.reinitialize to initialize levelSetFunction as a signed
% % distance function
% Phi = levelSet.reinitialize(Phi,h) ;

Phi = removeInnerContours(Phi) ;

end

%=========================================================================

% Remove artificial inner contours

function Phi = removeInnerContours(Phi)

I = find(Phi==0) ;
[i,j,k] = ind2sub(size(Phi),I) ;
for inode = 1: numel(i)
    neighbors = [   i(inode)-1 j(inode) k(inode) ;
                    i(inode)+1 j(inode) k(inode) ;
                    i(inode) j(inode)-1 k(inode) ;
                    i(inode) j(inode)+1 k(inode) ;
                    i(inode) j(inode) k(inode)-1 ;
                    i(inode) j(inode) k(inode)+1 ] ;
    mask =  ( neighbors(:,1)>0 & neighbors(:,1)<=size(Phi,1) ) & ...
            ( neighbors(:,2)>0 & neighbors(:,2)<=size(Phi,2) ) & ...
            ( neighbors(:,3)>0 & neighbors(:,3)<=size(Phi,3) ) ;
    IDX = sub2ind( size(Phi), neighbors(mask,1), neighbors(mask,2), neighbors(mask,3) ) ;
    Phi_local = Phi(IDX) ;
    Phi_local = Phi_local(Phi_local~=0) ;   % Remove null elements
    Phi_sign = sign( Phi_local ) ;
    if all(Phi_sign>0) | all(Phi_sign<0)
        % Set current sample as average of its neighbors (arbitrary choice)
        Phi( i(inode), j(inode), k(inode) ) = mean(Phi_local) ;
    end
end
end