function [IDX_narrowBand,IDX_safetyBand] = initNarrowBand(SDF,narrowBandSize,safetySize)

IDX_narrowBand = find( abs(SDF) <= narrowBandSize ) ;  % indices of points in narrow band
IDX_safetyBand = find( abs(SDF) <= safetySize ) ; 
IDX_safetyBand = setdiff(IDX_narrowBand,IDX_safetyBand) ;   % indices of points in safety band (used to reinitialize narrow band when needed)

end