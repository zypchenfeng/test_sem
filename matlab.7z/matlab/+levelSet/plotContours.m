function fig = plotContours(X,Y,Z,levelSetFunction,contours,fig_handle)

    if nargin<5
        contours = [] ;
    end

    if nargin<6
        fig = figure;
        cbh = colorbar;         % colorbar only added to new figure
        contour_handle = @contourf ;
    else
        fig = figure(fig_handle) ; hold on
        contour_handle = @contour ;
    end

    [~, index_y] = min(abs(Y(1,:,1))) ;     % plot section at y=0
    xlin = X(:,1,1) ;
    zlin = reshape(Z(1,1,:),size(Z,3),[]) ;
    
    phi0 = reshape(levelSetFunction(:,index_y,:),size(X,1),[]).' ;
    if isempty(contours)
        contour_handle(xlin,zlin,phi0,'k-','linewidth',2) ;
    else
        contour_handle(xlin,zlin,phi0,contours,'k-','linewidth',2) ;
    end
    xlabel('x [nm]'), ylabel('z [nm]'), axis tight
    set(gca,'fontsize',16,'ydir','normal')
    set(gca, 'XMinorGrid', 'on', 'YMinorGrid', 'on')
    axis([-500 500 -200 50])
    xlim auto
    daspect([1 1 1])
    set(gcf, 'Position', [200, 300, 1600, 500]) 

end