function z0 = extractMinZ(X,Y,Z,levelSetFunction) 

    z0 = max(Z(:)) ;
    xlin = X(:,1,1) ;
    zlin = reshape(Z(1,1,:),size(Z,3),[]) ;
    
    for index_y = 1: size(levelSetFunction,2)
        phi0 = reshape(levelSetFunction(:,index_y,:),size(X,1),[]).' ;
        C0 = geometry.extractContour(xlin,zlin,phi0) ;
        z0 = min( z0, min(C0(2,:)) ) ;
    end
    
end