function Phi = computeDistanceFunction(X,Y,Z,shape)

    % Compute normal unit vectors and barycenter for each face
    normalVectors = zeros( size(shape.bottomPolygon,1)+2, 3 ) ;
    barycenters = normalVectors ;
    % Bottom face
    normalVectors(1,:) = - cross( shape.bottomPolygon(2,:)-shape.bottomPolygon(1,:), shape.bottomPolygon(3,:)-shape.bottomPolygon(2,:) ) ;
    barycenters(1,:) = mean(shape.bottomPolygon) ;
    % Top face
    normalVectors(2,:) = cross( shape.topPolygon(2,:)-shape.topPolygon(1,:), shape.topPolygon(3,:)-shape.topPolygon(2,:) ) ;
    barycenters(2,:) = mean(shape.topPolygon) ;
    % Lateral faces
    numberOfEdges = size(shape.bottomPolygon,1);
    for iEdge = 1: numberOfEdges
        edge1 = shape.bottomPolygon(1+mod(iEdge,numberOfEdges),:) - shape.bottomPolygon(iEdge,:) ;
        edge2 = shape.topPolygon(iEdge,:) - shape.bottomPolygon(iEdge,:) ;
        normalVectors(iEdge+2,:) = cross(edge1,edge2) ;
        barycenters(iEdge+2,:) = mean( ...
            [ shape.bottomPolygon(iEdge,:) ;
            shape.bottomPolygon(1+mod(iEdge,numberOfEdges),:) ;
            shape.topPolygon(1+mod(iEdge,numberOfEdges),:) ;
            shape.topPolygon(iEdge,:) ] ) ;
    end
    % Normalize to get unit vectors
    normalVectors = bsxfun(@rdivide,normalVectors,sqrt(sum(normalVectors.^2,2)));
    % Compute signed distance
    SDF = Inf(numel(X),1) ;
    for iFace = 1: size(normalVectors,1)
        rVector = [ X(:), Y(:), Z(:) ] - barycenters(iFace,:) ;
        signedDistance = -sum(bsxfun(@times,rVector,normalVectors(iFace,:)),2) ;
        SDF = min(SDF,signedDistance) ;
    end
    
    Phi = reshape(SDF,size(X)) ;

end