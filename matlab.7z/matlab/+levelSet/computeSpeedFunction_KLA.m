function speedFunction = computeSpeedFunction_KLA(levelSetFunction,h,IDX_narrowBand,fluxMag,fluxAngle,materialIndicator,materials,etchStep,source_type)

    % source_type is 'ion' (default) or 'neutral'
    if nargin<9 | (~strcmpi(source_type,'ion') & ~strcmpi(source_type,'neutral') )
        source_type = 'ion' ;
    end

    speedFunction = zeros(size(levelSetFunction)) ;

    % Estimate normal unit vector
    [ normalUnitVectorX, normalUnitVectorY, normalUnitVectorZ ] = ...
        levelSet.normal(levelSetFunction,h);
    cosTheta = -normalUnitVectorZ ;
    sinThetaSquared = normalUnitVectorX.^2 + normalUnitVectorY.^2 ;
    
    for iMaterial = 1: numel(materials)
        I = (materialIndicator(IDX_narrowBand)==iMaterial) ;
        if strcmpi(source_type,'ion')
            speedFunction(IDX_narrowBand(I)) = materials{iMaterial}.etchRateH_i(etchStep) + fluxMag(I) .* ...
                ( (materials{iMaterial}.etchRateV_i(etchStep)-materials{iMaterial}.etchRateH_i(etchStep)) * ...
                ( 1+materials{iMaterial}.facetingParameter_i(etchStep)*sinThetaSquared(IDX_narrowBand(I)) ) .* abs(cosTheta(IDX_narrowBand(I))) ) ;
        else
            speedFunction(IDX_narrowBand(I)) = materials{iMaterial}.etchRateH_n(etchStep) + fluxMag(I) .* ...
                ( (materials{iMaterial}.etchRateV_n(etchStep)-materials{iMaterial}.etchRateH_n(etchStep)) * ...
                ( 1+materials{iMaterial}.facetingParameter_n(etchStep)*sinThetaSquared(IDX_narrowBand(I)) ) .* abs(cosTheta(IDX_narrowBand(I))) ) ;
        end
    end

    % Extend speed function
    defaultEtchRate = max(speedFunction(IDX_narrowBand)) ;
    I = (materialIndicator(IDX_narrowBand)==0) ;
    speedFunction(IDX_narrowBand(I)) = defaultEtchRate ;

end


