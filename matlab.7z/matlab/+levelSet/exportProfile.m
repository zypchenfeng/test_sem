function [single_gauge_result] = exportProfile(X,Y,Z,levelSetFunction, stack, filename, resolution)

    if nargin<7
        resolution = 0.01 ;
    end

    [~, index_y] = min(abs(Y(1,:,1))) ;     % plot section at y=0
    xlin = X(:,1,1) ;
    zlin = reshape(Z(1,1,:),size(Z,3),[]) ;
    
    phi0 = reshape(levelSetFunction(:,index_y,:),size(X,1),[]).' ;
    C0 = geometry.extractContour(xlin,zlin,phi0) ;
    
    if resolution>0
        C0 = resolution*round(C0/resolution) ;
    end
    dlmwrite(filename, C0', ',') ;
    
    %% section to measure the CD at the following the gauge center setting
    if isfield(stack,'CDinfo')
        [gauge_CD] = levelSet.measureCD_xz(C0', -150);
        if numel(gauge_CD) == 0
            gauge_CD = 999;
        end
%     
%     figure, plot(C0(1,:),C0(2,:),'linewidth',2)
%     xlabel('x [nm]'), ylabel('z [nm]'), grid minor, axis tight
%     set(gca,'fontsize',16,'ydir','normal')
%     axis([-500 500 -200 50])
%     xlim auto
%     daspect([1 1 1])
%     set(gcf, 'Position', [200, 300, 1600, 500]) 

    fprintf([stack.CDinfo.name, ' has CD of: ', num2str(gauge_CD), ...
          ' nm. \n Bias is: ', num2str(-(gauge_CD - stack.CDinfo.ADI_Model_CD)*stack.CDinfo.tonesgn), ...
          ' nm. \n Error is: ', num2str(gauge_CD - stack.CDinfo.waferCD), ' nm. \n']);
      
    single_gauge_result = {strcat(stack.CDinfo.name, ','), strcat(stack.CDinfo.type, ','), ...
               strcat(num2str(stack.CDinfo.tonesgn), ','), strcat(num2str(stack.CDinfo.waferCD), ','), ...
               strcat(num2str(stack.CDinfo.costwt), ','), strcat(num2str(stack.CDinfo.EEB_Model_CD), ','), ...
               strcat(num2str(stack.CDinfo.ADI_Model_CD), ','), strcat(num2str(stack.CDinfo.ILS), ','), ...
               strcat(num2str(gauge_CD), ','), strcat(num2str(gauge_CD - stack.CDinfo.waferCD), ','),...
               strcat(num2str((gauge_CD - stack.CDinfo.waferCD)^2), ',')};
    end

end