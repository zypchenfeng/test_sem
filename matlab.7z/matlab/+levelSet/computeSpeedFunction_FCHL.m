%% computeSpeedFunction_FCHL.m
%
% Description:
%   Implementation of the speed function proposed by Feng Chen in http://jira-brion.asml.com/browse/DOM-13919
%   This function uses c1 = etchRateV_i (vertical etch rate from ions) and
%   c2 = etchRateV_n (vertical etch rate from neutrals), where etchRateV_i
%   and etchRateV_n are parameters read from the material database file
%
% Use:
%   speedFunction = computeSpeedFunction_FCHL(levelSetFunction,h,IDX_narrowBand,fluxMag,fluxAngle,materialIndicator,materials,etchStep,source_type)
%
% INPUTS:
%   levelSetFunction: the 3D matrix sampling the level set function
%   h: vector of dimension 3 collecting the discretization size in x,y,z,
%   respectively
%   IDX_narrowBand: the linear index identifying elements in the
%   computational domain (all 3D matrices) belonging to the narrow band)
%   fluxMag: vector of size numel(IDX_narrowBand) containing the magnitude
%   of the flux vector inside the narrow band
%   fluxAngle: vector of size numel(IDX_narrowBand) containing the angle
%   of the flux vector inside the narrow band
%   materialIndicator: the 3D matrix collecting the index of the material
%   contained in each voxel
%   materials: structure containing material parameters (etch rates)
%   etchStep: the current etch step (from 1 to 4) in a multi-step etch process
%
% OPTIONAL INPUT PARAMETERS:
%   source_type: 'ion' (default) or 'neutral' selects the corresponding
%   etch rates, if the computed contribution is due to ions or neutrals,
%   respectively
%
% OUTPUTS:
%   speedFunction: the 3D matrix sampling the speed function

% Author : Alessandro Francavilla (AFRH)ionSpreadAngle
%          ASML
% email  : alessandro.francavilla@asml.com
% Website:
%
% Implementation: August 2018
% Revisions     : 2018-08-27, First implementation (AFRH)
%

function speedFunction = computeSpeedFunction_FCHL(levelSetFunction,h,IDX_narrowBand,fluxMag, ...
    fluxAngle,materialIndicator,materials,etchStep,loading_factor, source_type)

    % source_type is 'ion' (default) or 'neutral'
    if nargin<10 | (~strcmpi(source_type,'ion') & ~strcmpi(source_type,'neutral') & ~strcmpi(source_type,'deposition') )
        source_type = 'ion' ;
    end

    if size(levelSetFunction,2)>2
        disp('Error: function computeSpeedFunction_FCHL supports only 2D stacks.')
        return
    end

    speedFunction = zeros(size(levelSetFunction)) ;

    % Estimate normal unit vector
    [ normalUnitVectorX, ~, normalUnitVectorZ ] = ...
        levelSet.normal(levelSetFunction,h);
    thetaNormal = atan2(-normalUnitVectorX,-normalUnitVectorZ) ;
    
    % (theta_norm - Theta_ion)
    theta = thetaNormal(IDX_narrowBand) - fluxAngle ;

    for iMaterial = 1: numel(materials)
        I = (materialIndicator(IDX_narrowBand)==iMaterial) ;
        if strcmpi(source_type,'ion')
            constant = materials{iMaterial}.etchRateV_i(etchStep) ;
            speedFunction(IDX_narrowBand(I)) = constant * fluxMag(I) .* cos( theta(I) ).*(1+...
                materials{iMaterial}.facetingParameter_i(etchStep)*sin(theta(I)).^2) ;
        elseif strcmpi(source_type, 'neutral')
            constant = materials{iMaterial}.etchRateV_n(etchStep) ;
            speedFunction(IDX_narrowBand(I)) = constant * fluxMag(I) .* cos( theta(I) ).*...
                (1+materials{iMaterial}.facetingParameter_n(etchStep)*sin(theta(I)).^2) + ...
                materials{iMaterial}.etchRateH_n(etchStep)*loading_factor;
        elseif strcmpi(source_type,'deposition')
            constant = materials{iMaterial}.etchRateV_d(etchStep) ;
            speedFunction(IDX_narrowBand(I)) = constant * fluxMag(I) .* cos( theta(I) ).*...
                (1+materials{iMaterial}.facetingParameter_d(etchStep)*sin(theta(I)).^2) + ...
                materials{iMaterial}.etchRateH_d(etchStep)*loading_factor;
        else
            sprintf('%s\n',['ERROR: ' source_type ' not supported in computeSpeedFunction_FCHL']) ;
            return
%         speedFunction(IDX_narrowBand(I)) = constant * fluxMag(I) .* cos( theta(I) ).*(1+0.1*sin(theta(I)).^2) + materials{1, 3}.etchRateH_n(1);
    end

    % Extend speed function
    defaultEtchRate = max(speedFunction(IDX_narrowBand)) ;
    I = (materialIndicator(IDX_narrowBand)==0) ;
    speedFunction(IDX_narrowBand(I)) = defaultEtchRate ;

end


