function materialIndicator = updateMaterial(levelSetFunction,materialIndicator,IDX)

I_etched = IDX( levelSetFunction(IDX) < 0 ) ;
materialIndicator(I_etched) = 0 ; 

I_deposited = setdiff(IDX,I_etched) ;
if isempty(I_deposited)
    return
end
gridSize = size(levelSetFunction) ;
[Ix, Iy, Iz] = ind2sub(gridSize,I_deposited) ;

I3D_neighbors = [   Ix-1    Iy      Iz ;
                    Ix+1    Iy      Iz ;
                    Ix      Iy-1    Iz ;
                    Ix      Iy+1    Iz ;
                    Ix      Iy      Iz-1 ;
                    Ix      Iy      Iz+1 
                ] ;
% Truncate within computational domain
I3D_neighbors = max(I3D_neighbors,[1 1 1]) ;
I3D_neighbors = min(I3D_neighbors,gridSize) ;
% Convert to linear index
I_neighbors = sub2ind(gridSize,I3D_neighbors(:,1),I3D_neighbors(:,2),I3D_neighbors(:,3)) ;
% Organize as a matrix with each row identifying a node and each column
% its neighboring nodes
I_neighbors = reshape(I_neighbors,[],6) ;
% Get the material for each neighbor
sameMaterial = materialIndicator(I_neighbors) ;
% Find indices corresponding to neihboring materials different from
% reference 
I_diff = (sameMaterial~=materialIndicator(I_deposited)) ;
% 
selectedMaterial = -ones(size(I_deposited)) ;
for iNeighbor = 1: size(I_diff,2)
    I = find(selectedMaterial==-1) ;
    IDX_select = I(I_diff(I,iNeighbor)) ;
    selectedMaterial(IDX_select) = materialIndicator(I_neighbors(IDX_select,iNeighbor)) ;
end
if any(selectedMaterial==-1)
    disp('Error in updateMaterial.')
end
materialIndicator(I_deposited) = selectedMaterial ;

end