function [] = plotCrossSection(X,Y,Z,levelSetFunction,z0)

    xlin = X(:,1,1) ;
    ylin = reshape(Y(1,:,1),size(levelSetFunction,2),[]) ;
    zlin = reshape(Z(1,1,:),size(levelSetFunction,3),[]) ;
    
    index_z2 = find(zlin > z0, 1, 'first');
    index_z1 = index_z2 - 1 ;
    if (index_z1==0)
        index_z1 = index_z1 + 1 ;
        index_z2 = index_z2 + 1 ;
    end
    z1 = zlin(index_z1) ;
    z2 = zlin(index_z2) ;
    
    t = (z0-z1)/(z2-z1) ;
    
    phi0 = t*levelSetFunction(:,:,index_z2) + (1-t)*levelSetFunction(:,:,index_z1) ;
    phi0 = reshape(phi0,size(X,1),[]).' ;
    figure
    contourf(xlin,ylin,phi0,[0 0],'k-') ;
    xlabel('x [nm]'), ylabel('y [nm]'), grid minor, axis equal
    set(gca,'fontsize',16,'ydir','normal')

end