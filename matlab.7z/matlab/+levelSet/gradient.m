function varargout = gradient(f,h)

%% Check inputs
numberOfDimensions = numel(size(f)) ;

if nargout~=numberOfDimensions
    disp('Error (gradient): the number of output arguments must be equal to the number of dimensions.')
end

if nargin<2
    h = ones(numberOfDimensions,1) ; 
else   
    % information on grid sampling is provided
    if numel(h)==1
        h = h * ones(numberOfDimensions,1) ;
    elseif numel(h)==numberOfDimensions
        % do nothing
    else
        disp('Error: h should be a scalar or a vector with numberOfDimensions elements.')
    end
end

%% Compute gradient
for iDim = 1: numberOfDimensions
    df = diff(f,1,iDim)/h(iDim);
    if iDim == 1
        df_minus = df( [end 1:end], :, : ) ;
        df_plus = df( [1:end 1], :, : ) ;
    elseif iDim == 2
        df_minus = df( :, [end 1:end], : ) ;
        df_plus = df( :, [1:end 1], : ) ;
    elseif iDim == 3
        df_minus = df( :, :, [end 1:end] ) ;
        df_plus = df( :, :, [1:end 1] ) ;
    end
    varargout{iDim} = (df_plus+df_minus)/2 ;
end

end