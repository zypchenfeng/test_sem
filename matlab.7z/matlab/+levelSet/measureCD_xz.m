function [gauge_CD] = measureCD_xz(profile, depth)
% Calculation method: first find the center location of the Etch_Area, then
% find the y and z coordinates of the surface area along the y direction.
% Build a function to calculate the coordinate from the cut line to all the
% small segments from y-z coordinate 

intersection = [];
iy = size(profile, 1);
cut1_end1.x1 = min(profile(:,1));     % define the coordinates of the cut line
cut1_end1.y1 = depth; 
cut1_end1.x2 = max(profile(:,1)); 
cut1_end1.y2 = cut1_end1.y1; 

for i = 1:iy-1
    seg.x1 = profile(i,1);
    seg.y1 = profile(i,2);
    seg.x2 = profile(i+1,1);
    seg.y2 = profile(i+1,2);
    [x, y] = intersect(cut1_end1, seg);   
    intersection = [intersection;[x, y]];
end

intersection = unique(round(intersection, 2), 'rows');
if isempty(intersection)
    gauge_CD = 999;
else
    left_pnt = max(intersection(intersection(:,1)<0)); % look at the intersection above the gauge center
    right_pnt = min(intersection(intersection(:,1)>0)); % look at the intersection below the gauge center
    gauge_CD = right_pnt - left_pnt;
end

% line_CD = [];
% trench_CD = [];
% 
% for i = 1:length(intersection)-1
%     if mod(i,2) == 0
%         line_CD = [line_CD, intersection(i+1, 1) - intersection(i, 1)];
%     else
%         trench_CD = [trench_CD, intersection(i+1, 1) - intersection(i, 1)];
%     end
% end
% line_CD = line_CD';
% trench_CD = trench_CD';

end
% calculate the intersection coordinates 
function [x, y] = intersect(seg1, seg2)
    x1 = seg1.x1; y1 = seg1.y1;
    x2 = seg1.x2; y2 = seg1.y2;
    x3 = seg2.x1; y3 = seg2.y1;
    x4 = seg2.x2; y4 = seg2.y2;
    cond1 = ccw_check([x1,y1], [x2,y2], [x3,y3]) ~= ccw_check([x1,y1], [x2,y2], [x4,y4])...
        && ccw_check([x3,y3], [x4,y4], [x1,y1]) ~= ccw_check([x3,y3], [x4,y4], [x2,y2]); %1->2->3 not the same as 1->2->4, and 3->4->1 not the same as 3->4->1
    if cond1
        bot = (x1-x2)*(y3-y4)-(y1-y2)*(x3-x4); %denominator
		x   = ((x1*y2-y1*x2)*(x3-x4)-(x1-x2)*(x3*y4-y3*x4))/bot; % find the intersection x coordinate
		y   = ((x1*y2-y1*x2)*(y3-y4)-(y1-y2)*(x3*y4-y3*x4))/bot; % find the intersection y coordinate
    else
        x = []; y = [];
    end        
end

% check the arrangement of 3 points
function [ccw] = ccw_check(A, B, C)
    %Tests whether the turn formed by A, B, and C is counter clock wise
    if (B(1) - A(1)) * (C(2) - A(2)) > (B(2) - A(2)) * (C(1) - A(1))
	ccw = 1;
    elseif (B(1) - A(1)) * (C(2) - A(2)) < (B(2) - A(2)) * (C(1) - A(1))
	ccw = 0;
    else
	ccw = 2;  %3 points in line	
    end
end
