%% LSM_Etch3D.m
% 
% Description:
%    Function to run the level set based etching simulation
%
%   [X,Y,Z,levelSetFunction] = LSM_Etch3D(inputStack, spatialResolution, sourceSettings, tMax, results_folder, flag_2D, save_gif)
%   inputStack: the filename of the input geometry (including path)
%   spatialResolution: the grid discretization (coherent with the stack
%   representation - typically nm)
%   sourceSettings: structure with fields 'ion' and 'neutral'; each of them
%   is on turn a structure with fields 'standardDeviation' and 'mean', the
%   standard deviation (sigma) and mean value of the Gaussian modelling 
%   ion and neutral distribution functions, respectively
%   tMax: the total simulation time (in seconds)
%   results_folder: the folder in which results will be saved
%
%   OPTIONAL INPUT PARAMETERS:
%   flag_2D: if true forces 2D simulation (the stack is considered
%   invariant along the y direction).
%   save_gif: if true a gif animation of the time-varying etch profile is
%   saved in 'results_folder'.
%   stepTime: if provided, stepTime is a vector collecting the time (in seconds) at
%   which each etch step ends. If not provided (or if stepTime=[]),
%   etch steps are controlled by etch depth.
%
%   OUTPUTS:
%   levelSetFunction: the level set function at the end of the simulation
%   X,Y,Z: the x,y,z coordinates of the computational grid (as obtained
%   with 'ndgrid' - see also NDGRID)

% Author : Alessandro Francavilla (AFRH)
%          ASML
% email  : alessandro.francavilla@asml.com  
% Website: 
%
% Implementation: June 2018 
% Revisions     : 2018-06-25, First implementation (AFRH)
% 

function [X,Y,Z,levelSetFunction, single_gauge_result] = LSM_Etch3D(inputStack, inputMaterials, ...
    spatialResolution, sourceSettings, tMax, results_folder, flag_2D, save_gif, stepTime, a, b)

controlByTime = false;  % => etch by depth
if nargin>=11
    % stepTime is provided => etch by time
    if ~isempty(stepTime)
        controlByTime = true;
    end
end

if nargin<8
    save_gif = false ;
	data_store = {};
end

if nargin<7
    flag_2D = false ;
end 

if ~isdir(results_folder)
    mkdir(results_folder);
end

%% Constants
maxNumberOfReinitializationSteps = 5 ; 
reinitializationTolerance = 1e-2 ;
CFL_limit = 0.25 ;

% Narrow band settings
narrowBandSize = 5 ;
safetySize = 2 ;

%% Simulation settings

% Load D4C stack
[stack, etchSettings.materials, numberOfLayers, steps] = mask.loadStack(inputStack,inputMaterials) ;
stack = mask.triangulateMask(stack) ;
stack.negativeToneMask = false ;       % set to true for negative tone resist
[flag_neutrals, flag_deposition] = mask.enableSources(etchSettings.materials(1:numberOfLayers)) ;

if flag_2D
    stack.pitch(2) = 0 ;                   % 2D simulation 
end
%% Setup computational grid
[X,Y,Z,h] = geometry.setupGrid(stack,cell2mat(etchSettings.materials),spatialResolution) ;

%% Start time-stepping

% Initialize level set function
levelSetFunction = levelSet.initSDF(X,Y,Z,stack.mask) ;

% Initialize material info 'material' stores, for each point of the computational domain, an index to identify the material 
etchSettings.materialIndicator = geometry.initializeMaterial(X,Y,Z,levelSetFunction,stack.mask,etchSettings.materials) ;

% Initialize narrow band method
% The safety band is a subset of the narrow band (the most exterior part of
% the narrow band): when the interface reaches the safety band, we need to reinitialize the narrow band (recenter it around the actual interface)
[IDX_narrowBand,IDX_safetyBand] = levelSet.initNarrowBand(levelSetFunction,narrowBandSize*max(h),(narrowBandSize-safetySize)*max(h)) ;
backgroundValue = narrowBandSize*max(h) ;

% Reinit level set function
levelSetFunction = levelSet.reinitialize(levelSetFunction,h,reinitializationTolerance,maxNumberOfReinitializationSteps,IDX_narrowBand) ;

% Initialize visibility function
t0 = tic ;
[THETA_ion,PHI_ion] = geometry.setupAngularGrid(sourceSettings.ion.theta0,sourceSettings.ion.phi0,sourceSettings.ion.standardDeviation,flag_2D) ;
if flag_neutrals
    [THETA_neutral,PHI_neutral] = geometry.setupAngularGrid(sourceSettings.neutral.theta0,sourceSettings.neutral.phi0,sourceSettings.neutral.standardDeviation,flag_2D) ;
end
if flag_deposition
    [THETA_deposition,PHI_deposition] = geometry.setupAngularGrid(sourceSettings.deposition.theta0,sourceSettings.deposition.phi0,sourceSettings.deposition.standardDeviation,flag_2D) ;
end

ionFluxMag = zeros(size(X)) ;
ionFluxAngle = zeros(size(X)) ;
[ ionFluxMag(IDX_narrowBand), ionFluxAngle(IDX_narrowBand) ] = ...
    geometry.computeFlux_raymarching(levelSetFunction,X,Y,Z,IDX_narrowBand,THETA_ion,PHI_ion,deg2rad(sourceSettings.ion.standardDeviation)^2,stack) ;
if flag_neutrals
    neutralFluxMag = ionFluxMag ;
    neutralFluxAngle = ionFluxAngle ;
    [ neutralFluxMag(IDX_narrowBand), neutralFluxAngle(IDX_narrowBand) ] = ...
        geometry.computeFlux_raymarching(levelSetFunction,X,Y,Z,IDX_narrowBand,THETA_neutral,PHI_neutral,deg2rad(sourceSettings.neutral.standardDeviation)^2,stack) ;
end
if flag_deposition
    depositionFluxMag = ionFluxMag ;
    depositionFluxAngle = ionFluxAngle ;
    [ depositionFluxMag(IDX_narrowBand), depositionFluxAngle(IDX_narrowBand) ] = ...
        geometry.computeFlux_raymarching(levelSetFunction,X,Y,Z,IDX_narrowBand,THETA_deposition,PHI_deposition,deg2rad(sourceSettings.deposition.standardDeviation)^2,stack) ;
end
elsapsedTime = toc(t0) ;
% fprintf('%s\n',['Time to initialize visibility function (ray tracing): ' num2str(round(elsapsedTime)) ' seconds']);
% fprintf('%s\n','')

% Plot initial profile
ADI_fig = geometry.plotMaterial(X,Y,Z,etchSettings); title('ADI profile') ;
ADI_fig = levelSet.plotContours(X,Y,Z,levelSetFunction,[0 0],ADI_fig) ;
pause(0.1);

% Artificially extend material properties within narrow band (for proper
% extention of speed function in air)
% This operation can be done once only under the assumption that the
% profile never grows, otherwise material info must be updated every
% iteration to account for material changes
for iter = 1: narrowBandSize+1
    I = find(etchSettings.materialIndicator(IDX_narrowBand)==0) ;
    etchSettings.materialIndicator = geometry.extendMaterial(etchSettings.materialIndicator,IDX_narrowBand(I), (iter==1) ) ;
end

t0 = tic ;

time = 0 ;
numberOfTimeSteps = 0 ;
etchStep = 1 ;
loading_factor = 1 + a*(stack.CDinfo.ResistRatio - b);

while time < tMax
    % Update level set function ONLY in narrow band   
    safetyCheckSign = sign(levelSetFunction(IDX_safetyBand)) ;      % when a point in the safety band changes sign we need to reinit the narrow band  
    speedFunction = levelSet.computeSpeedFunction_FCHL( ...
        levelSetFunction,h,IDX_narrowBand,ionFluxMag(IDX_narrowBand),ionFluxAngle(IDX_narrowBand), ...
        etchSettings.materialIndicator, etchSettings.materials, etchStep , loading_factor) ;
    % Add neutral contribution
    if flag_neutrals
        speedFunction = speedFunction + levelSet.computeSpeedFunction_FCHL( ...
            levelSetFunction,h,IDX_narrowBand,neutralFluxMag(IDX_narrowBand),neutralFluxAngle(IDX_narrowBand), ...
            etchSettings.materialIndicator, etchSettings.materials, etchStep, loading_factor, 'neutral') ;
    end
    if flag_deposition
        speedFunction = speedFunction + levelSet.computeSpeedFunction_FCHL( ...
            levelSetFunction,h,IDX_narrowBand,depositionFluxMag(IDX_narrowBand),depositionFluxAngle(IDX_narrowBand), ...
            etchSettings.materialIndicator, etchSettings.materials, etchStep, loading_factor, 'deposition') ;
    end    
    maxSpeedFunction = max(abs(speedFunction(IDX_narrowBand))) ;
    dt = CFL_limit * min(h) / maxSpeedFunction ;
    if (controlByTime & (time+dt)>stepTime(etchStep) )
        dt = stepTime(etchStep)-time+0.001 ;
    end
    time = time + dt ;
    numberOfTimeSteps = numberOfTimeSteps + 1 ;
    levelSetUpdate = dt*levelSet.computeUpdateNarrowBand(levelSetFunction,h,speedFunction,IDX_narrowBand,size(levelSetFunction)) ;
    levelSetFunction(IDX_narrowBand) = levelSetFunction(IDX_narrowBand)-levelSetUpdate(IDX_narrowBand) ;
    
    % Update narrow band
    if any( sign(levelSetFunction(IDX_safetyBand))~=safetyCheckSign )
%         disp('Reinitializing narrow band...')
        ionFluxMag(IDX_narrowBand) = 0 ;
        ionFluxAngle(IDX_narrowBand) = 0 ;
        if flag_neutrals
            neutralFluxMag(IDX_narrowBand) = 0 ;
            neutralFluxAngle(IDX_narrowBand) = 0 ;
        end
        [IDX_narrowBand,IDX_safetyBand] = levelSet.initNarrowBand(levelSetFunction,narrowBandSize*max(h),(narrowBandSize-safetySize)*max(h)) ;
        % Update background value
        IDX_inactive = setdiff(1:numel(levelSetFunction),IDX_narrowBand);
        levelSetFunction(IDX_inactive) = sign(levelSetFunction(IDX_inactive)) * backgroundValue ;        
        % Compute visibility function 
        IDX = IDX_narrowBand ;
        [ ionFluxMag(IDX), ionFluxAngle(IDX) ] = ...
            geometry.computeFlux_raymarching(levelSetFunction,X,Y,Z,IDX,THETA_ion,PHI_ion,deg2rad(sourceSettings.ion.standardDeviation)^2,stack) ;
        if flag_neutrals
            [ neutralFluxMag(IDX), neutralFluxAngle(IDX) ] = ...
                geometry.computeFlux_raymarching(levelSetFunction,X,Y,Z,IDX,THETA_neutral,PHI_neutral,deg2rad(sourceSettings.neutral.standardDeviation)^2,stack) ;
        end
        if flag_deposition
            [ depositionFluxMag(IDX_narrowBand), depositionFluxAngle(IDX_narrowBand) ] = ...
                geometry.computeFlux_raymarching(levelSetFunction,X,Y,Z,IDX,THETA_deposition,PHI_deposition,deg2rad(sourceSettings.deposition.standardDeviation)^2,stack) ;
        end

    end
    
    % Reinitialize distance function
    levelSetFunction = levelSet.reinitialize(levelSetFunction,h,reinitializationTolerance,maxNumberOfReinitializationSteps,IDX_narrowBand) ;
    
    % Update etch step
    if controlByTime
        etchStep = find(time <= stepTime, 1,'first') ;
    else
        z0 = levelSet.extractMinZ(X,Y,Z,levelSetFunction) ;
        etchStep = find(z0 <= steps, 1,'last') ;
    end
   
    % Generate gif
    if save_gif
        if exist('gifHandle','var')
            saveGif(X,Y,Z,levelSetFunction,stack,time,[],gifHandle) ;
        else
            filename = [results_folder 'EtchedProfile_' datestr(now,'yyyymmddTHHMMSS') '.gif'] ;
            gifHandle = saveGif(X,Y,Z,levelSetFunction,stack,time,filename) ;
        end
    end
    
end

elsapsedTime = toc(t0) ;
% fprintf('%s\n',['Time for level set updates: ' num2str(round(elsapsedTime)) ' seconds']);

% Plot after etch profile
etchSettings.materialIndicator( levelSetFunction < 0 ) = 0 ;    % Plot as white the etched volume
AEI_fig = geometry.plotMaterial(X,Y,Z,etchSettings); title('AEI profile') ;
AEI_fig = levelSet.plotContours(X,Y,Z,levelSetFunction,[0 0],AEI_fig) ;

% Export profile
[single_gauge_result] = levelSet.exportProfile(X,Y,Z,levelSetFunction, stack, [results_folder 'ExportedProfile_' datestr(now,'yyyymmddTHHMMSS') '.csv'], 0.01 ) ;

% Render 3D stack
if ~flag_2D
    figure; levelSet.plotInterface(X,Y,Z,levelSetFunction,stack); set(gca,'fontsize',16)
end