function drawVisibility(X,Y,Z,V,phi)

    xlin = X(:,1,1) ;
    zlin = reshape(Z(1,1,:),size(Z,3),[]) ;
    V0 = reshape(V(:,1,:),size(X,1),[]).' ;
    phi0 = reshape(phi(:,1,:),size(X,1),[]).' ;
    figure, imagesc(xlin,zlin,V0), set(gca,'ydir','normal'), colorbar
    hold on
    contour( xlin, zlin, phi0, [0 0], 'k-', 'linewidth', 2 )
    set(gca,'fontsize',16)

end