function Phi = init(X,Y,Z,h,masks)

tolerance = 1e-2 ;

Phi = zeros(size(X)) ;

X2D = X(:,:,1) ; 
Y2D = Y(:,:,1) ; 
zlin = reshape(Z(1,1,:),[],1) ; 
Phi(Z<0) = 1 ;
Phi(Z>0) = -1 ;
for iMask = 1: numel(masks)
    thisMask = masks{iMask} ;
    zmin = thisMask.bottomPolygon(1,3) ;
    zmax = thisMask.topPolygon(1,3) ;
    zIndices = find(zlin>=zmin & zlin<zmax) ;
    for iSlice = 1: numel(zIndices)
        z0 = zlin(zIndices(iSlice)) ;
        t = (z0-zmin)/(zmax-zmin) ;
        thisPolygon = t*thisMask.topPolygon + (1-t)*thisMask.bottomPolygon ;
        xmin = min(thisPolygon(:,1))-tolerance ; xmax = max(thisPolygon(:,1))+tolerance ;
        ymin = min(thisPolygon(:,2))-tolerance ; ymax = max(thisPolygon(:,2))+tolerance ;
        IDX = find(X2D>xmin & X2D<xmax & Y2D>ymin & Y2D<ymax) ;
        [IN,ON] = inpolygon( X2D(IDX), Y2D(IDX), thisPolygon(:,1), thisPolygon(:,2) ) ;
        Phi( IDX(IN) + (zIndices(iSlice)-1)*numel(X2D) ) = 1 ;
        Phi( IDX(ON) + (zIndices(iSlice)-1)*numel(X2D) ) = 0 ;
    end
end

% % Use levelSet.reinitialize to initialize levelSetFunction as a signed
% % distance function
Phi = levelSet.reinitialize(Phi,h) ;