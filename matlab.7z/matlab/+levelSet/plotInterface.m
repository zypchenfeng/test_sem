function [] = plotInterface(X,Y,Z,F,CD_profile)

    if size(Y,2)>1
        % 3D problem
        iso = isosurface(X, Y, Z, F, 0) ;
        h = gca ;
        if isempty(get(h,'Children'))
            p = patch(iso);
            p.FaceColor = 'green';
            p.EdgeColor = 'none';
            grid minor
            daspect([1 1 1])
            view(3)
            camlight
%             set(gca,'color','k')
%             set(gcf,'color','k')
        else
            delete(get(h,'Children'))
            p = patch(iso);            
            p.FaceColor = 'green';
            p.EdgeColor = 'none';
            camlight
        end

        % Add mask
        if nargin>4
            hold on
            for iMask = 1: numel(CD_profile.mask)
                mask.plotMask(CD_profile.mask{iMask},'blue',CD_profile.pitch) ;     
            end
            hold off
        end
        
    else
        % 2D problem
        x = X(:,1,1) ; x = x(:) ;
        z = Z(1,1,:) ; z = z(:) ;
        F2D = reshape(F,numel(x),[]) ;
        contourf(x,z,F2D',[0 0],'k-')
        
        % Add mask
        if nargin>4
            hold on
            for iMask = 1: numel(CD_profile.mask)
                mask.plotMask(CD_profile.mask{iMask},'blue',CD_profile.pitch) ;     
            end
            hold off
        end
        
        xlabel('x [nm]'), ylabel('z [nm]'), grid minor
    end
    
end