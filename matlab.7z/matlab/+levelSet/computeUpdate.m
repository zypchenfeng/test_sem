function dPhi = computeUpdate(f,h,pressureFunction,c)

numberOfDimensions = numel(size(f)) ;

if nargin<4
    c = 0 ; 
end

nabla_plus = zeros(size(f));
nabla_minus = nabla_plus ;
for iDim = 1: numberOfDimensions
    df = diff(f,1,iDim)/h(iDim);
    if iDim == 1
        df_minus = df( [end 1:end], :, : ) ;
        df_plus = df( [1:end 1], :, : ) ;
    elseif iDim == 2
        if isempty(df)
            % 2D problem
            df_minus = zeros(size(f)) ;
            df_plus = zeros(size(f)) ;
        else
            df_minus = df( :, [end 1:end], : ) ;
            df_plus = df( :, [1:end 1], : ) ;
        end        
    elseif iDim == 3
        df_minus = df( :, :, [end 1:end] ) ;
        df_plus = df( :, :, [1:end 1] ) ;
    end
    nabla_plus = nabla_plus + max(df_minus,0).^2 + min(df_plus,0).^2 ;
    nabla_minus = nabla_minus + min(df_minus,0).^2 + max(df_plus,0).^2 ;
end

nabla_plus = sqrt(nabla_plus) ;
nabla_minus = sqrt(nabla_minus) ;

dPhi = max(pressureFunction,0).*(nabla_plus-c)+min(pressureFunction,0).*(nabla_minus-c);

end