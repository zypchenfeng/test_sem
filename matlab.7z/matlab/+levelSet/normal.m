%% normal.m
% 
% Description:
%    Computes the normal unit vector to each level set 
%
% References:
%   Average one-sided difference scheme described by eq. (4.23) in
%   Sethian, J.A and Strain, J.D., "Crystal growth and dendritric
%   solidification", J Comp Phys, vol. 98, pp. 231-253, 1992.

% Author : Alessandro Francavilla (AFRH)
%          ASML
% email  : alessandro.francavilla@asml.com  
% Website: 
%
% Implementation: March 2018 
% Revisions     : 2018-03-01, First implementation (AFRH)
% 

function varargout = normal(f,h)

% Normal unit vector Average one-sided difference

tolerance = 10*eps ;

%% Check inputs
numberOfDimensions = numel(size(f)) ;

if nargout~=numberOfDimensions
    disp('Error (normal): the number of output arguments must be equal to the number of dimensions.')
end

if nargin<2
    h = ones(numberOfDimensions,1) ; 
else   
    % information on grid sampling is provided
    if numel(h)==1
        h = h * ones(numberOfDimensions,1) ;
    elseif numel(h)==numberOfDimensions
        % do nothing
    else
        disp('Error: h should be a scalar or a vector with numberOfDimensions elements.')
    end
end

%% Compute normal unit vector

normalUnitVector{1} = zeros(size(f)) ; 
normalUnitVector{2} = normalUnitVector{1} ;
normalUnitVector{3} = normalUnitVector{1} ;
numberOfAverages = zeros(size(f)) ;

for iDim = 1: numberOfDimensions
    df = diff(f,1,iDim)/h(iDim);
    if iDim == 1
        df_minus{iDim} = df( [end 1:end], :, : ) ;
        df_plus{iDim} = df( [1:end 1], :, : ) ;
    elseif iDim == 2
        if isempty(df)
            % 2D problem
            df_minus{iDim} = zeros(size(f)) ;
            df_plus{iDim} = zeros(size(f)) ;
        else
            df_minus{iDim} = df( :, [end 1:end], : ) ;
            df_plus{iDim} = df( :, [1:end 1], : ) ;
        end
    elseif iDim == 3
        df_minus{iDim} = df( :, :, [end 1:end] ) ;
        df_plus{iDim} = df( :, :, [1:end 1] ) ;
    end
end

for ix = 1: 2
    iDim = 1 ;
    if ix==1
        dx = df_plus{iDim} ;
    else
        dx = df_minus{iDim} ;
    end
    for iy = 1: 2
        iDim = 2 ;
        if iDim>numberOfDimensions
            dy = 0 ;
        else
            if iy==1
                dy = df_plus{iDim} ;
            else
                dy = df_minus{iDim} ;
            end
        end
        for iz = 1: 2
            iDim = 3 ;
            if iDim>numberOfDimensions
                dz = 0 ;
            else   
                if iz==1
                    dz = df_plus{iDim} ;
                else
                    dz = df_minus{iDim} ;
                end
            end
            normSquared = dx.^2 + dy.^2 + dz.^2 ;
            IDX = (normSquared>tolerance) ;
            norm2 = sqrt(normSquared) ;
            norm2(~IDX) = 1 ;
            numberOfAverages = numberOfAverages + IDX ;
            normalUnitVector{1} = normalUnitVector{1} + dx./norm2 ;
            if numberOfDimensions>1
                normalUnitVector{2} = normalUnitVector{2} + dy./norm2 ;
            end
            if numberOfDimensions>2
                normalUnitVector{3} = normalUnitVector{3} + dz./norm2 ;
            end            
        end 
    end
end

IDX = (numberOfAverages==0) ;
for iDim = 1: numberOfDimensions
    varargout{iDim} = normalUnitVector{iDim} ./ numberOfAverages ;
    varargout{iDim}(IDX) = 0 ;
end

% Normalize
normSquared = zeros(size(f)) ;
for iDim = 1: numberOfDimensions
    normSquared = normSquared + varargout{iDim}.^2 ;
end
IDX = normSquared>1e-12 ;
norm2 = sqrt(normSquared) ;
norm2(~IDX) = 1 ;
for iDim = 1: numberOfDimensions
    varargout{iDim} = varargout{iDim}./norm2 ;
end

end