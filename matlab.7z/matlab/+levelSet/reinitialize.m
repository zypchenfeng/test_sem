function levelSetFunction = reinitialize(levelSetFunction,h,tolerance,maxNumberOfReinitializationSteps,IDX)

if nargin<4
    maxNumberOfReinitializationSteps = 100;
end

if nargin<3
    tolerance = 0.01;
end

if (nargin<5)
    IDX = (1:numel(levelSetFunction)) ;
end

dt = .5*min(h) ;    % using unitary speed, minimum grid size, and CFL limit = 0.5 (to check!!!)

for ir = 1:maxNumberOfReinitializationSteps                             % reinitialization steps
    levelSetFunctionOld = levelSetFunction(IDX) ;
    smoothedSignFunction = levelSetFunction./sqrt(levelSetFunction.^2+min(h)^2) ;
    levelSetFunction = levelSetFunction-dt*levelSet.computeUpdate(levelSetFunction,h,smoothedSignFunction,1);
    res = norm(levelSetFunctionOld-levelSetFunction(IDX),Inf) / norm(h,Inf) ;
    if res<tolerance
        break
    end
end 