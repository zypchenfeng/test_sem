function C0 = extractContour(x,y,phi)    

    C = contourc(x,y,phi,[0 0]) ;
    C0 = [] ;
    iContour = 0 ;
    iStart = 2 ;
    while (iStart<size(C,2))
        iContour = iContour + 1 ;
        np = C(2,iStart-1) ;
        localContour = C(:,iStart:iStart+np-1) ;
        if size(localContour,2)>size(C0,2)
            C0 = localContour ;
        end
        iStart = iStart + (np+1) ; 
    end
    
end