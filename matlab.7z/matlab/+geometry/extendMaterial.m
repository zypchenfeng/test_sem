function extendedMaterial = extendMaterial(materialIndicator,I,reset)

% Assign nearest neighbor material to voxels with materialIndicator==0
% If all neighbors have materialIndicator=0, material is unchanged

persistent sizeA

if nargin==3 & reset
    sizeA = size(materialIndicator) ;
    [~, ~] = neighbour26([], [], [] , [], reset) ;
end

if isempty(sizeA)
    sizeA = size(materialIndicator) ;
end

extendedMaterial = materialIndicator ;

IDX = materialIndicator(I)==0 ;
[i,j,k] = ind2sub(size(materialIndicator),I(IDX)) ;
for inode = 1: numel(i)
    [idx3d, linidx] = neighbour26(i(inode), j(inode), k(inode), sizeA) ;
    firstOccurrence = linidx(find(materialIndicator(linidx)~=0,1,'first')) ;
    if ~isempty(firstOccurrence)
        % update material
        extendedMaterial(i(inode), j(inode), k(inode)) = materialIndicator(firstOccurrence) ;
    end
end

end

% =============================================================== 
%                   PRIVATE FUNCTIONS
% =============================================================== 

function [idx3d, linidx] = neighbour26(i, j, k, sizeA, reset)
  %returns the indices of the 26 3-D neighbors of location i, j, k within Your3DMatrix
  %The second output is the linear indices -- useful for extracting content

  % Adapted from:
  % https://uk.mathworks.com/matlabcentral/answers/310452-how-can-i-find-26-neighbors-of-point-with-coordinates-of-i-j-k#answer_258769

  persistent matrixOffset

  if nargin==5 & reset
      matrixOffset = [] ;
      idx3d = [] ;
      linidx = [] ;
      return
  end

  if isempty(matrixOffset)
      [R, C, P] = ndgrid(-1:1, -1:1, -1:1);
      matrixOffset = [R(:), C(:), P(:)];
      matrixOffset(14,:) = [] ;    %remove center 
      if sizeA(2)==1
          I = find(matrixOffset(:,2)==0) ;
          matrixOffset = matrixOffset(I,:) ;
      end
  end

    rows = sizeA(1) ;
    cols = sizeA(2) ;
    pages = sizeA(3) ;
    idx3d = [i,j,k] + matrixOffset ;
    valid = idx3d(:,1) >= 1 & idx3d(:,2) >= 1 & idx3d(:,3) >= 1 & idx3d(:,1) <= rows & idx3d(:,2) <= cols & idx3d(:,3) <= pages;
    linidx = idx3d(valid,1) + (idx3d(valid,2)-1)*rows + (idx3d(valid,3)-1)*rows*cols ;   % Faster replacement of sub2ind
    idx3d = idx3d(valid,:) ;
end