function shadow = computeShadow_raymarching(F,X,Y,Z,x,y,z,thetaGrid,phiGrid,varargin)

%% Check if all the sizes match
SameSize = (any(size(x)==size(y)) && ...
  any(size(x)==size(z)) );
assert(SameSize && size(x,2)==1, ...
  'x, y, z vectors have to be in Nx1 format.');
numberOfPoints = numel(x) ;

SameSize = any(size(thetaGrid)==size(phiGrid)) ;
assert(SameSize, ...
  'thetaGrid and phiGrid must have the same size.');
numberOfDirections = numel(thetaGrid) ;
xDirections = sin(thetaGrid) .* cos(phiGrid) ;
yDirections = sin(thetaGrid) .* sin(phiGrid) ;
zDirections = cos(thetaGrid) ;

if numel(varargin)>0
    intersection = varargin{1} ;
else
    intersection = false(numberOfDirections*numberOfPoints,1) ;
end

%% Prepare inputs for ray/mask intersection
rayOrigin = [x y z] ;
rayOrigin = reshape(repmat(rayOrigin',numberOfDirections,1),3,[])' ;

rayDirection = [ xDirections(:) yDirections(:) zDirections(:) ] ;
rayDirection = repmat(rayDirection,numberOfPoints,1) ;

intersection = raymarch_bottomUp(F,X,Y,Z,rayOrigin,rayDirection,intersection) ;

% Reshape intersection to a matrix with rows corresponding to rays and columns
% corresponding to origin of rays (points on the computational grid)
shadow = reshape(intersection,[],numberOfPoints) ;

end

% =============================================================== 
%                   PRIVATE FUNCTIONS
% =============================================================== 

function intersection = raymarch(F,X,Y,Z,origin,direction,intersection)

scale = 1.01 ;
tolerance = 0.001;   % Arbitrary tolerance
maxiter = 20 ;     % If algo reaches maxiter, I assume no blockage

xmin = X(1,1,1) ;
xmax = X(end,1,1) ;
ymin = Y(1,1,1) ;
ymax = Y(1,end,1) ;
zmin = Z(1,1,1) ;
zmax = Z(1,1,end) ;

t = (zmax-origin(:,3)) ./ direction(:,3) ;
x0 = origin(:,1) + t.*direction(:,1) ;
y0 = origin(:,2) + t.*direction(:,2) ;
z0 = origin(:,3) + t.*direction(:,3) ;

% (xs,ys) is the image of (x0,y0) in the base cell (where SDF is sampled)
xs = xmin + mod(x0-xmin,xmax-xmin) ;
ys = ymin + mod(y0-ymin,ymax-ymin) ;
zs = z0 ;
if size(X,2)==1
    distance = F(xs,zs) ;
else
    distance = F(xs,ys,zs) ;
end

I = (z0>origin(:,3)) & (intersection==false) ;

iter = 0 ;
while any(I) && iter<maxiter
    
    iter = iter+1 ;
       
    x0(I) = x0(I) + scale*distance(I).*direction(I,1) ;
    y0(I) = y0(I) + scale*distance(I).*direction(I,2) ;
    z0(I) = z0(I) + scale*distance(I).*direction(I,3) ;
    
    % (xs,ys) is the image of (x0,y0) in the base cell (where SDF is sampled)
    xs(I) = xmin + mod(x0(I)-xmin,xmax-xmin) ;
    ys(I) = ymin + mod(y0(I)-ymin,ymax-ymin) ;
    zs(I) = z0(I) ;
    
    if size(X,2)==1
        distance(I) = F(xs(I),zs(I)) ;
    else
        distance(I) = F(xs(I),ys(I),zs(I)) ;
    end
    
    I_int = (z0>origin(:,3)) & (distance>-tolerance) ;
    intersection(I_int) = true ;
    
    I = (z0>origin(:,3)) & (intersection==false) ;
    
end

end


function intersection = raymarch_bottomUp(F,X,Y,Z,origin,direction,intersection)

% Start from the surface, try to reach z=zmax

scaleFactor = 1.0 ;
maxiter = 10 ;     % If algo reaches maxiter, I assume no blockage
flag_2D = (size(X,2)==1) ;

xmin = X(1,1,1) ;
xmax = X(end,1,1) ;
ymin = Y(1,1,1) ;
ymax = Y(1,end,1) ;
zmin = Z(1,1,1) ;
zmax = Z(1,1,end) ;
voxelSize = X(2)-X(1) ;

% Move upward for 0.5*voxelSize (arbitrary)
t = 0.5*voxelSize ;
x0 = origin(:,1) + t.*direction(:,1) ;
y0 = origin(:,2) + t.*direction(:,2) ;
z0 = origin(:,3) + t.*direction(:,3) ;

% (xs,ys) is the image of (x0,y0) in the base cell (where SDF is sampled)
xs = xmin + mod(x0-xmin,xmax-xmin) ;
ys = ymin + mod(y0-ymin,ymax-ymin) ;
zs = z0 ;
if flag_2D
    distance = F(xs,zs) ;
else
    distance = F(xs,ys,zs) ;
end

I = (intersection==false) ;
if flag_2D
    samples = [ x0(I), z0(I) ] ;
    dir = [ direction(I,1), direction(I,3) ] ;
else
    samples = [ x0(I), y0(I), z0(I) ] ;
    dir = direction(I,:) ;
end
dist = distance(I) ;

iter = 0 ;
while any(I) && iter<maxiter
    
    iter = iter+1 ;

    tmp = bsxfun( @times, dist, dir ) ;
    samples = bsxfun( @minus, samples, scaleFactor*tmp ) ;  

    % (xs,ys) is the image of (x0,y0) in the base cell (where SDF is sampled)
    if flag_2D
        tmp = mod ( bsxfun( @minus, samples, [xmin, 0] ), [ xmax-xmin, 0 ] ) ;
        samples = bsxfun( @plus, [xmin, 0], tmp ) ;
        distance(I) = F( samples(:,1), samples(:,2) ) ;
        x0(I) = samples(:,1) ;
        z0(I) = samples(:,2) ;
    else
        tmp = mod ( bsxfun( @minus, samples, [xmin, ymin, 0] ), [ xmax-xmin, ymax-ymin, 0 ] ) ;
        samples = bsxfun( @plus, [xmin, ymin, 0], tmp ) ;
        distance(I) = F( samples(:,1), samples(:,2), samples(:,3) ) ;
        x0(I) = samples(:,1) ;
        y0(I) = samples(:,2) ;
        z0(I) = samples(:,3) ;
    end
    
    I_int = (distance>0) ;
    intersection(I_int) = true ;
    
    I = (z0<zmax) & (intersection==false) ;
    if flag_2D
        samples = [ x0(I), z0(I) ] ;
        dir = [ direction(I,1), direction(I,3) ] ;
    else
        samples = [ x0(I), y0(I), z0(I) ] ;
        dir = direction(I,:) ;
    end
    dist = distance(I) ;
    
end

end