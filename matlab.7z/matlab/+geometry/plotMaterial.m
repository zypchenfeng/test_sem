function fig = plotMaterial(X,Y,Z,etchSettings)

    [~, index_y] = min(abs(Y(1,:,1))) ;     % plot section at y=0
    xlin = X(:,1,1) ;
    zlin = reshape(Z(1,1,:),size(Z,3),[]) ;
    
    M0 = reshape(etchSettings.materialIndicator(:,index_y,:),size(X,1),[]).' ;
    usedMaterials = unique(M0) ;
    numberOfMaterials = numel(usedMaterials) ;
    myColorMap = hsv(numberOfMaterials) ;   
    fig = figure; imagesc(xlin,zlin,M0) ;
    cbh = colorbar; 
    ticks = linspace( cbh.Limits(1), cbh.Limits(2), 2*(numberOfMaterials)+1 ) ;
    cbh.Ticks = ticks(2:2:end) ;
    for iMaterial = 1: numberOfMaterials
        if usedMaterials(iMaterial)==0
            cbh.TickLabels{iMaterial} = 'Air' ;
            myColorMap(iMaterial,:) = 1 ; 
        else
            cbh.TickLabels{iMaterial} = etchSettings.materials{usedMaterials(iMaterial)}.name ;
        end
    end
    colormap(myColorMap);
    cbh.TickLabelInterpreter = 'none' ;
    xlabel('x [nm]'), ylabel('z [nm]'), grid minor, axis tight
    set(gca,'fontsize',16,'ydir','normal')
    axis([-500 500 -200 50])
    daspect([1 1 1])
    set(gcf, 'Position', [200, 300, 1600, 500])     
end