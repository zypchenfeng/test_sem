function visibilityFunction = computeVisibility(X,Y,Z,THETA,PHI,ionSpreadAngleSquared,stack)

chunkSize = 2000 ;
numberOfPoints = numel(X) ;

% Generate periodic copies of the mask along x and y
xShift = [0 1 -1] * stack.pitch(1) ;
if stack.pitch(2)>0
    yShift = [0 1 -1] * stack.pitch(2) ;
else
    % 2D problem
    yShift = 0 ;
end

% Initialize visibility function
visibilityFunction = zeros( size(X) ) ;

% Initialize ion flux
ionDistribution = exp( -THETA.^2 / (2*ionSpreadAngleSquared) ) / (2*pi*ionSpreadAngleSquared);    
dTheta = diff(THETA(1:2)) ;
dPhi = diff(PHI(1,1:2)) ;
commonIntegrand = dTheta * dPhi * sin(THETA(:)) .* ionDistribution(:) ;
% Normalize to unitary energy
commonIntegrand = commonIntegrand / sum(commonIntegrand) ;

% Reshape vectors as column vectors
X = reshape(X,[],1) ;
Y = reshape(Y,[],1) ;
Z = reshape(Z,[],1) ;

numberOfChunks = ceil(numberOfPoints/chunkSize) ;
for iChunk = 0: numberOfChunks-1
    iStart = 1 + iChunk*chunkSize ;
    iEnd = min( iStart + chunkSize - 1, numberOfPoints ) ;
    localShadow = zeros(numel(THETA),iEnd-iStart+1) ;
    for dx = xShift       % it is convenient to intersect first the base cell (ix=0), assuming it will be the dominant contribution to shadow
        for dy = yShift
            for iMask = 1: numel(stack.mask)               
                localShadow = or( localShadow, ...
                    geometry.computeShadow_checkAABB(X(iStart:iEnd)+dx,Y(iStart:iEnd)+dy,Z(iStart:iEnd),stack.mask{iMask},THETA,PHI, localShadow(:)) ) ; 
            end
        end
    end
    if (stack.negativeToneMask)
        visibilityFunction(iStart:iEnd) = sum ( commonIntegrand .* (localShadow) ) ;
    else
        visibilityFunction(iStart:iEnd) = sum ( commonIntegrand .* (~localShadow) ) ;
    end
end

end