% function Phi = init(X,Y,Z,masks)
function materialInfo = initializeMaterial(X,Y,Z,phi,masks,materials)

tolerance = 1e-2 ;

materialInfo = zeros(size(phi)) ;

X2D = X(:,:,1) ; 
Y2D = Y(:,:,1) ; 
zlin = reshape(Z(1,1,:),[],1) ; 

% Add layers
% Assume materials stored from bottom to top
A = cell2mat(materials) ;
IDX_layerMaterials = find( [A.thickness]>0 ) ;

z1 = 0 ;
for iMaterial = numel(IDX_layerMaterials):-1:1
    z0 = z1 - materials{IDX_layerMaterials(iMaterial)}.thickness ;
    materialInfo(phi>=0 & Z<z1) = IDX_layerMaterials(iMaterial);
    z1 = z0 ;
end

% Add hard masks
for iMask = 1: numel(masks)
    thisMask = masks{iMask} ;
    zmin = thisMask.bottomPolygon(1,3) ;
    zmax = thisMask.topPolygon(1,3) ;
    zIndices = find(zlin>=zmin & zlin<zmax) ;
    for iSlice = 1: numel(zIndices)
        z0 = zlin(zIndices(iSlice)) ;
        t = (z0-zmin)/(zmax-zmin) ;
        thisPolygon = t*thisMask.topPolygon + (1-t)*thisMask.bottomPolygon ;
        xmin = min(thisPolygon(:,1))-tolerance ; xmax = max(thisPolygon(:,1))+tolerance ;
        ymin = min(thisPolygon(:,2))-tolerance ; ymax = max(thisPolygon(:,2))+tolerance ;
        IDX = find(X2D>xmin & X2D<xmax & Y2D>ymin & Y2D<ymax) ;
        [IN,ON] = inpolygon( X2D(IDX), Y2D(IDX), thisPolygon(:,1), thisPolygon(:,2) ) ;
        materialInfo( IDX(IN) + (zIndices(iSlice)-1)*numel(X2D) ) = thisMask.material ;
        materialInfo( IDX(ON) + (zIndices(iSlice)-1)*numel(X2D) ) = thisMask.material ;
    end
end

end
