function R = getRotationMatrix(u,v)
% Compute rotation matrix to rotate u to v (v=R*u, when u and v are unit vectors)

k = cross(u,v) ;
if norm(k)>1e-6
    k = k / norm(k) ;
end
cos_theta = dot(u,v) / (norm(u)*norm(v)) ;
sin_theta = sqrt(1-cos_theta^2) ;

I = eye(3) ;

k_cross_I = [ cross(k,I(:,1)) cross(k,I(:,2)) cross(k,I(:,3)) ] ;

R = cos_theta*I + (1-cos_theta)*k*k' + sin_theta*k_cross_I ;