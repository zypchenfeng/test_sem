function [X,Y,Z,h] = setupGrid(stack,materials,spatialResolution) 

    h_materials = [materials.thickness] ;
    zmin = -sum( h_materials ) ;
    
    A = cell2mat(stack.mask);
    topPolygons = vertcat(A.topPolygon) ;
    zmax = max( topPolygons(:,3) ) ;
    zmax = max(0,zmax) + spatialResolution * 4;
    
    numberOfSamples(1) = max(1, round( stack.pitch(1)/spatialResolution + 1 ) ) ;
    numberOfSamples(2) = max(1, round( stack.pitch(2)/spatialResolution + 1 ) ) ;
    numberOfSamples(3) = max(1, round( (zmax-zmin)/spatialResolution + 1 ) ) ;
    x = linspace(-stack.pitch(1)/2,stack.pitch(1)/2,numberOfSamples(1)) ;
    y = linspace(-stack.pitch(2)/2,stack.pitch(2)/2,numberOfSamples(2)) ;
    z = linspace(zmin,zmax,numberOfSamples(3)) ;
    [X,Y,Z] = ndgrid( x,y,z ) ;
    
    if numel(y)>1
        % 3D problem
        h = [ diff(x(1:2)) diff(y(1:2)) diff(z(1:2)) ] ;
    else
        % 2D problem 
        h = [ diff(x(1:2)) 0 diff(z(1:2)) ] ;
        h(2) = min(h(1),h(3)) ;
    end    
      
end