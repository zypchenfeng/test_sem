function shadow = computeShadow_checkAABB(x,y,z,mask,thetaGrid,phiGrid,varargin)

%% Check if all the sizes match
SameSize = (any(size(x)==size(y)) && ...
  any(size(x)==size(z)) );
assert(SameSize && size(x,2)==1, ...
  'x, y, z vectors have to be in Nx1 format.');
numberOfPoints = numel(x) ;

SameSize = any(size(thetaGrid)==size(phiGrid)) ;
assert(SameSize, ...
  'thetaGrid and phiGrid must have the same size.');
numberOfDirections = numel(thetaGrid) ;
xDirections = sin(thetaGrid) .* cos(phiGrid) ;
yDirections = sin(thetaGrid) .* sin(phiGrid) ;
zDirections = cos(thetaGrid) ;

if numel(varargin)>0
    intersect = varargin{1} ;
else
    intersect = false(numberOfDirections*numberOfPoints,1) ;
end

%% Prepare inputs for ray/mask intersection
rayOrigin = [x y z] ;
rayOrigin = reshape(repmat(rayOrigin',numberOfDirections,1),3,[])' ;

rayDirection = [ xDirections(:) yDirections(:) zDirections(:) ] ;
rayDirection = repmat(rayDirection,numberOfPoints,1) ;

% Set tolerance for AABB check
tolerance = 1e-2;   % Arbitrary

%% Triangulate mask
T = mask.mesh.tri ;
V = mask.mesh.nodes ;
vertex0 = V(T(:,1),:) ;
vertex1 = V(T(:,2),:) ;
vertex2 = V(T(:,3),:) ;
numberOfTriangles = size(T,1) ;

%% Bounding box check
% Build bounding box
xmin = min( V(:,1) ) ;
xmax = max( V(:,1) ) ;
ymin = min( V(:,2) ) ;
ymax = max( V(:,2) ) ;
zmin = min( V(:,3) ) ;
zmax = max( V(:,3) ) ;

%% Compute intersections vs triangulated mask
% intersect = false(numberOfDirections*numberOfPoints,1) ;
% Compute multiple rays vs single triangle
% This operation can be vectorized (single call)

% Exclude rays outside AABB
alpha0 = bsxfun(@rdivide, zmin-rayOrigin(:,3), rayDirection(:,3) ) ;
alpha1 = bsxfun(@rdivide, zmax-rayOrigin(:,3), rayDirection(:,3) ) ;
x0intersect = bsxfun(@plus, rayOrigin(:,1), bsxfun(@times,alpha0,rayDirection(:,1)) ) ;
y0intersect = bsxfun(@plus, rayOrigin(:,2), bsxfun(@times,alpha0,rayDirection(:,2)) ) ;
x1intersect = bsxfun(@plus, rayOrigin(:,1), bsxfun(@times,alpha1,rayDirection(:,1)) ) ;
y1intersect = bsxfun(@plus, rayOrigin(:,2), bsxfun(@times,alpha1,rayDirection(:,2)) ) ;
IDX_toCheck =   (x0intersect>=xmin-tolerance | x1intersect>=xmin-tolerance) & (x0intersect<=xmax+tolerance | x1intersect<=xmax+tolerance) & ...
                (y0intersect>=ymin-tolerance | y1intersect>=ymin-tolerance) & (y0intersect<=ymax+tolerance | y1intersect<=ymax+tolerance) ;
            
start = rayOrigin(IDX_toCheck,:) ;
dir = rayDirection(IDX_toCheck,:) ;
intersect_toCheck = intersect(IDX_toCheck) ;
intersect_local = intersect_toCheck ;            

for iTriangle = 1: numberOfTriangles
%     [intersectSingleFace, t, u, v, xcoor] = geometry.TriangleRayIntersection.TriangleRayIntersection (...
%         rayOrigin, rayDirection , vertex0(iTriangle,:), vertex1(iTriangle,:), vertex2(iTriangle,:) ) ;
%     intersect = or(intersect,intersectSingleFace) ;
    if all(intersect_toCheck) 
        break;
    end
    IDX_global = find(intersect_toCheck==false) ;
    IDX_local = find(intersect_local==false) ;
    start = start(IDX_local,:) ;
    dir = dir(IDX_local,:) ;
    [intersectSingleFace, ~, ~, ~, ~] = geometry.TriangleRayIntersection.TriangleRayIntersection (...
        start, dir , vertex0(iTriangle,:), vertex1(iTriangle,:), vertex2(iTriangle,:), ...
        'border', 'inclusive') ;
    intersect_local = or(intersect_toCheck(IDX_global),intersectSingleFace) ;
    intersect_toCheck(IDX_global) = intersect_local ;
end

intersect(IDX_toCheck) = intersect_toCheck ;

% Reshape intersect to a matrix with rows corresponding to rays and columns
% corresponding to origin of rays (points on the computational grid)
shadow = reshape(intersect,[],numberOfPoints) ;

end
