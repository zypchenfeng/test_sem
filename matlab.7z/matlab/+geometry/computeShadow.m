function shadow = computeShadow(x,y,z,mask,thetaGrid,phiGrid,varargin)

%% Check if all the sizes match
SameSize = (any(size(x)==size(y)) && ...
  any(size(x)==size(z)) );
assert(SameSize && size(x,2)==1, ...
  'x, y, z vectors have to be in Nx1 format.');
numberOfPoints = numel(x) ;

SameSize = any(size(thetaGrid)==size(phiGrid)) ;
assert(SameSize, ...
  'thetaGrid and phiGrid must have the same size.');
numberOfDirections = numel(thetaGrid) ;
xDirections = sin(thetaGrid) .* cos(phiGrid) ;
yDirections = sin(thetaGrid) .* sin(phiGrid) ;
zDirections = cos(thetaGrid) ;

if numel(varargin)>0
    intersect = varargin{1} ;
else
    intersect = false(numberOfDirections*numberOfPoints,1) ;
end

%% Prepare inputs for ray/mask intersection
rayOrigin = [x y z] ;
rayOrigin = reshape(repmat(rayOrigin',numberOfDirections,1),3,[])' ;

rayDirection = [ xDirections(:) yDirections(:) zDirections(:) ] ;
rayDirection = repmat(rayDirection,numberOfPoints,1) ;

%% Triangulate mask
T = mask.mesh.tri ;
V = mask.mesh.nodes ;
vertex0 = V(T(:,1),:) ;
vertex1 = V(T(:,2),:) ;
vertex2 = V(T(:,3),:) ;
numberOfTriangles = size(T,1) ;

%% Compute intersections vs triangulated mask
% intersect = false(numberOfDirections*numberOfPoints,1) ;
% Compute multiple rays vs single triangle
% This operation can be vectorized (single call)
start = rayOrigin ;
dir = rayDirection ;
intersect_local = intersect ;
for iTriangle = 1: numberOfTriangles
%     [intersectSingleFace, t, u, v, xcoor] = geometry.TriangleRayIntersection.TriangleRayIntersection (...
%         rayOrigin, rayDirection , vertex0(iTriangle,:), vertex1(iTriangle,:), vertex2(iTriangle,:) ) ;
%     intersect = or(intersect,intersectSingleFace) ;
    if all(intersect) 
        break;
    end
    IDX_global = find(intersect==false) ;
    IDX_local = find(intersect_local==false) ;
    start = start(IDX_local,:) ;
    dir = dir(IDX_local,:) ;
    [intersectSingleFace, ~, ~, ~, ~] = geometry.TriangleRayIntersection.TriangleRayIntersection (...
        start, dir , vertex0(iTriangle,:), vertex1(iTriangle,:), vertex2(iTriangle,:), ...
        'border', 'inclusive') ;
    intersect_local = or(intersect(IDX_global),intersectSingleFace) ;
    intersect(IDX_global) = intersect_local ;
end

% Reshape intersect to a matrix with rows corresponding to rays and columns
% corresponding to origin of rays (points on the computational grid)
shadow = reshape(intersect,[],numberOfPoints) ;

end
