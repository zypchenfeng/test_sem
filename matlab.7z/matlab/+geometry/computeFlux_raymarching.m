function [fluxMag, fluxAngle]  = computeFlux_raymarching(SDF,X,Y,Z,IDX,THETA,PHI,ionSpreadAngleSquared,stack)

chunkSize = 2000 ;
numberOfPoints = numel(IDX) ;

% Generate periodic copies of the mask along x and y
xShift = [0 1 -1] * stack.pitch(1) ;
if stack.pitch(2)>0
    flag_2D = false ;
    yShift = [0 1 -1] * stack.pitch(2) ;
else
    % 2D problem
    flag_2D = true ;
    yShift = 0 ;
end

% Initialize visibility function
fluxMag = zeros( size(IDX) ) ;
fluxAngle = zeros( size(IDX) ) ;

% Initialize ion flux
ionDistribution = exp( -THETA.^2 / (2*ionSpreadAngleSquared) ) / (2*pi*ionSpreadAngleSquared);    
commonIntegrand = ionDistribution(:) ;
if ~flag_2D
    commonIntegrand = commonIntegrand .* sin(THETA(:)) ;
end
% Normalize to unitary energy
commonIntegrand = commonIntegrand / sum(commonIntegrand) ;

% Estimate normal unit vector
if ~flag_2D
    % 3D problem
    h = [ X(2,1,1)-X(1,1,1) Y(1,2,1)-Y(1,1,1) Z(1,1,2)-Z(1,1,1) ] ;
else
    % 2D problem 
    h = [ X(2,1,1)-X(1,1,1) 0 Z(1,1,2)-Z(1,1,1) ] ;
    h(2) = min(h(1),h(3)) ;
end   
[ normalUnitVectorX, normalUnitVectorY, normalUnitVectorZ ] = ...
    levelSet.normal(SDF,h);

% Setup interpolant
if flag_2D
    F = griddedInterpolant(reshape(X,size(SDF,1),[]),reshape(Z,size(SDF,1),[]),reshape(SDF,size(SDF,1),[])) ;
    Nx = griddedInterpolant(reshape(X,size(SDF,1),[]),reshape(Z,size(SDF,1),[]),reshape(normalUnitVectorX,size(SDF,1),[])) ;
    Ny = griddedInterpolant ;
    Nz = griddedInterpolant(reshape(X,size(SDF,1),[]),reshape(Z,size(SDF,1),[]),reshape(normalUnitVectorZ,size(SDF,1),[])) ;
else
    F = griddedInterpolant(X,Y,Z,SDF) ;
    Nx = griddedInterpolant(X,Y,Z,normalUnitVectorX) ;
    Ny = griddedInterpolant(X,Y,Z,normalUnitVectorY) ;
    Nz = griddedInterpolant(X,Y,Z,normalUnitVectorZ) ;
end

numberOfChunks = ceil(numberOfPoints/chunkSize) ;
for iChunk = 0: numberOfChunks-1
    iStart = 1 + iChunk*chunkSize ;
    iEnd = min( iStart + chunkSize - 1, numberOfPoints ) ;
    I = IDX(iStart:iEnd) ;
    origin = [ X(I), Y(I), Z(I) ] ;
    normal = [ normalUnitVectorX(I), normalUnitVectorY(I), normalUnitVectorZ(I) ] ;
    [x,y,z] = levelSet.closestSurfacePoint(SDF,F,X,Y,Z,Nx,Ny,Nz,origin,I) ;
    localShadow = zeros(numel(THETA),iEnd-iStart+1) ;
    for dx = xShift       % it is convenient to intersect first the base cell (ix=0), assuming it will be the dominant contribution to shadow
        for dy = yShift
            localShadow = or( localShadow, ...
                geometry.computeShadow_raymarching(F,X,Y,Z,x+dx,y+dy,z,THETA,PHI, localShadow(:)) ) ;
        end
    end
    if (stack.negativeToneMask)
        fluxMag(iStart:iEnd) = sum ( commonIntegrand .* (localShadow) ) ;
        fluxAngle(iStart:iEnd) = sum ( commonIntegrand .* THETA(:) .* (localShadow) ) ;
    else
        fluxMag(iStart:iEnd) = sum ( commonIntegrand .* (~localShadow) ) ;
        fluxAngle(iStart:iEnd) = sum ( commonIntegrand .* THETA(:) .* (~localShadow) ) ;
    end
end
fluxAngle = fluxAngle ./ fluxMag ;

end