function [THETA,PHI] = setupAngularGrid(theta0,phi0,sigma,flag_2D)

if nargin<4
    flag_2D = false;
end

maxTheta = 3*sigma ;
angularResolutionTheta = sigma/3.0 ;

if flag_2D & theta0<1e-6      % Special case: Angular sampling reduces to the xz plane 
    angularResolutionPhi = 180. ; 
    phi0 = 0 ;
else
    angularResolutionPhi = 10*angularResolutionTheta ;        % deg
end   

% Compute temporary (full and fine) grid
step = .1 ;
if flag_2D
    % for convenience using negative theta
    theta = (-90:step:90) ;
    phi = 0;
else
    theta = (0:step:90);
    phi = (phi0-180:step:phi0+180);
end
[THETA,PHI] = ndgrid( theta, phi ) ;    % meshgrid interchanges the first 2 dimensions for easier plotting in cartesian coordinates

X = sind(THETA).*cosd(PHI) ;
Y = sind(THETA).*sind(PHI) ;
Z = cosd(THETA) ;
V = [X(:) Y(:) Z(:)] ;

zhat = [0;0;1] ;
beamCenter = [ sind(theta0)*cosd(phi0); sind(theta0)*sind(phi0); cosd(theta0)] ;
R = geometry.getRotationMatrix(beamCenter,zhat);     % Rotation matrix (theta0,phi0)->(0,0)

U = (R*V')' ;

X_new = U(:,1) ;
Y_new = U(:,2) ;
Z_new = U(:,3) ;
theta_new = atan2(sqrt(X_new.^2+Y_new.^2),Z_new) ;
B = reshape( theta_new<deg2rad(maxTheta), size(THETA) ) ;
% figure, imagesc(phi,theta,B), set(gca,'fontsize',16,'ydir','normal'), xlabel('\phi'), ylabel('\theta')

% Compute actual grid
thetaMin = min(THETA(B(:))) ;
thetaMax = max(THETA(B(:))) ;
phiMin = min(PHI(B(:))) ;
phiMax = max(PHI(B(:))) ;
if abs((phiMax-phiMin)-360)<1e-6
    phiMax = phiMax - angularResolutionPhi ;
end
numberOfThetaPoints = round( (thetaMax-thetaMin)/angularResolutionTheta ) + 1 ;
numberOfPhiPoints = round( (phiMax-phiMin)/angularResolutionPhi ) + 1 ;
theta = linspace( deg2rad(thetaMin), deg2rad(thetaMax), numberOfThetaPoints ) ;
phi = linspace( deg2rad(phiMin), deg2rad(phiMax), numberOfPhiPoints ) ; 

[THETA,PHI] = ndgrid( theta, phi ) ;    % meshgrid interchanges the first 2 dimensions for easier plotting in cartesian coordinates

end