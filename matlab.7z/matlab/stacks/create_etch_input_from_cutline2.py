from gauge_helper import GaugeSlicer, CrossSection

import os
import argparse
dir_path = os.path.dirname(os.path.realpath(__file__))

def input_header(major_size, minor_size):
    header_str = '''[pitch]
{0} {1}
[layers]
SiN_Stop 30.000000 1.000000 0.100000 0.200000  1.000000 0.100000 0.200000
SiOx 20.000000 100.000000 0.100000 0.200000 40.000000 0.100000 0.200000
SOC 50.000000 100.000000 0.100000 0.200000 0.000000 -5.100000 0.200000
SOG 20.000000   80.000000 1.100000 0.200000 -10.000000 -10.100000 0.200000'''.format(
        major_size, minor_size)
    return header_str


def generate_1d_etch_input(gauge_file, work_dir, height, major_size, minor_size, swa_function_str, gauge_name_in):
    gauge_slicer = GaugeSlicer(gauge_file)
    found_gauge = False
    for gauge_name in gauge_slicer.gauges:
        if gauge_name_in is not None and gauge_name != gauge_name_in:
            continue
        else:
            found_gauge = True
        file_name = os.path.join(work_dir, gauge_name + '.cross')
        if os.path.isfile(file_name):
            print "{0} : generating etch input file".format(gauge_name)
        else:
            print "!!! there is no cross-section for gauge {0}".format(gauge_name)
            continue
        cross_section = CrossSection.load(file_name)
        cross_section.swa_function = swa_function_str
        mask_string = cross_section.generate_1d_mask(height, minor_size)
        with open(os.path.join(work_dir, gauge_name + '.input'), 'w') as f:
            print >> f, input_header(major_size, minor_size)
            print >> f, mask_string
            print >> f, gauge_slicer.get_sliced(gauge_name, {'resist_ratio':cross_section.resist_ratio(major_size)})
    if not found_gauge:
        raise Exception, 'Cannot find gauge {0} in {1}'.format(gauge_name_in, gauge_file)

def main(swa_function_str, gauge_name):
    work_dir = dir_path + '/work1'
    gauge_file = dir_path + '/work1/1DGauges_1um.txt'
    if not swa_function_str or len(swa_function_str) == 0:
        swa_function_str = '89.75 - 1. / 40 * (5 * min(150, trench_cd) + 4 * min(200, resist_cd))'
    print "using swa_function: {0}".format(swa_function_str)
    height = 40.
    minor_size = 100.
    major_size = 4000.
    generate_1d_etch_input(gauge_file, work_dir, height, major_size, minor_size, swa_function_str, gauge_name)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Create cross section to resist profile')
    swa_function_help = 'function to calculate swa, for example: \n'
    swa_function_help = swa_function_help + ' "89.75 - 1. / 40 * (5 * min(150, trench_cd) + 4 * min(200, resist_cd))"'
    parser.add_argument('-s', dest='swa_function', help=swa_function_help)
    parser.add_argument('-g', dest='gauge_name', help='name of the gauge')

    args = parser.parse_args()
    main(args.swa_function, args.gauge_name)
