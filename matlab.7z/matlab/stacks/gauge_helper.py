import json
import math


def resist_postfix():
    return '2 4 0.300000 0.100000 0.200000 1.000000 0.100000 0.200000'


class CutLine:
    def __init__(self, x1, x2):
        if x1 <= x2:
            self.head = x1
            self.tail = x2
        else:
            self.head = x2
            self.tail = x1

    def to_dict(self):
        return {'head': self.head, 'tail': self.tail}

    @staticmethod
    def from_dict(dict_in):
        return CutLine(dict_in['head'], dict_in['tail'])

    def generate_1D_mask(self, index, height, y_width, swa1=90, swa2=90, delimiter=' '):
        result = ''
        result += 'Resist_' + str(index) + delimiter + resist_postfix() + '\n'

        # z heights
        result += '0.0' + delimiter + str(height) + '\n'

        # vertices at Z = 0
        result += str(self.head) + delimiter + str(-y_width/2) + delimiter
        result += str(self.tail) + delimiter + str(-y_width/2) + delimiter
        result += str(self.tail) + delimiter + str( y_width/2) + delimiter
        result += str(self.head) + delimiter + str( y_width/2)
        result += '\n'

        # vertices at Z = height
        delta_x1 = 0 if swa1 == 90 else height / math.tan(math.radians(swa1))
        delta_x2 = 0 if swa2 == 90 else height / math.tan(math.radians(swa2))
        result += str(self.head + delta_x1) + delimiter + str(-y_width/2) + delimiter
        result += str(self.tail - delta_x2) + delimiter + str(-y_width/2) + delimiter
        result += str(self.tail - delta_x2) + delimiter + str( y_width/2) + delimiter
        result += str(self.head + delta_x1) + delimiter + str( y_width/2)
        return result


class CrossSection:
    def __init__(self, name, is_X, cutlines):
        self.cutlines = cutlines
        self.is_X = is_X
        self.name = name
        self.is_resist = True  # gauge measure on resist, other wise, gauge measures on trench
        self.swas = []  # swa of cut lines
        self.swa_function = None

    def resist_ratio(self, major_size):
        length = 0
        for c in self.cutlines:
            length += c.tail - c.head
        ratio = length / major_size
        if not self.is_resist:
            ratio = 1 - ratio
        return ratio
    def save(self, file_name):
        tmp = {}
        for attr in ('is_X', 'name', 'is_resist', 'swas'):
            tmp[attr] = getattr(self, attr)
        tmp['cutlines'] = [c.to_dict() for c in self.cutlines]
        with open(file_name, 'w') as f:
            json.dump(tmp, f)

    @staticmethod
    def load(file_name):
        cross = CrossSection(None, None, None)
        with open(file_name, 'r') as f:
            tmp = json.load(f)
        for attr in ('is_X', 'name', 'is_resist', 'swas'):
            setattr(cross, attr, tmp[attr])
        cross.cutlines = [CutLine.from_dict(c) for c in tmp['cutlines']]
        return cross

    def invert(self, major_size):
        # x_size is the size of the area of interest in major_direction
        # invert the tone of gauges
        pts = []
        for g in self.cutlines:
            pts.append(g.head)
            pts.append(g.tail)
        pts.sort()
        if pts[0] <= -major_size / 2:
            pts = pts[1:]
        else:
            pts = [-major_size / 2] + pts

        if pts[-1] >= major_size / 2:
            pts = pts[:-2]
        else:
            pts = pts + [major_size / 2]

        self.cutlines = []
        for i in range(len(pts)/2):
            cutline = CutLine(pts[i*2], pts[i*2+1])
            self.cutlines.append(cutline)

        self.is_resist = not self.is_resist

    def calculate_swa(self):
        # assume that all gauges are sorted already
        pts = [-1.e100]
        for g in self.cutlines:
            pts.append(g.head)
            pts.append(g.tail)
        pts.append(1e100)

        for i in range(1, len(pts) - 1):
            left_cd = pts[i] - pts[i-1]
            right_cd = pts[i+1] - pts[i]
            is_left_edge = bool(i % 2)
            if is_left_edge:
                # assume gauge is resist now
                trench_cd, resist_cd = left_cd, right_cd
            else:
                resist_cd, trench_cd = left_cd, right_cd
            if not self.is_resist:
                trench_cd, resist_cd = resist_cd, trench_cd
            if self.swa_function:
                swa = eval(self.swa_function)
                #print "using external swa_function {} = {}".format(self.swa_function, swa)
            else:
                swa = 89.75 - 1. / 40 * (5 * min(150, trench_cd) + 4 * min(200, resist_cd))
                #print "using built-in swa_function = {}".format(swa)
            self.swas.append(swa)

    def generate_1d_mask(self, height, y_width):
        '''
        :param cross_section:
        :return:
        output format:
        [shapes]
        Resist_1
        0.000000 40.000000
        -500.000000  -300.000000 -340.000000  -300.000000 -340.000000 300.000000 -500.000000 300.000000
        -500.000000  -300.000000 -360.000000  -300.000000 -360.000000 300.000000 -500.000000 300.000000
        Resist_2 2 4 0.300000 0.100000 0.200000 1.000000 0.100000 0.200000
        0.000000 40.000000
        -80.000000  -300.000000 -30.000000  -300.000000 -30.000000 300.000000 -80.000000 300.000000
        -70.000000  -300.000000 -40.000000  -300.000000 -40.000000 300.000000 -70.000000 300.000000

        Each group is from one gauge measurement results. first two numbers are Z coordinates. second line
        is vertices in first Z plane and second is vertices in second Z plan.
        '''
        self.calculate_swa()
        # "size =f cutline = {}, size of swa = {}".format(len(self.cutlines), len(self.swas))
        result = '[shapes]'
        for i in range(len(self.cutlines)):
            result += '\n'
            swa1 = self.swas[i*2]
            swa2 = self.swas[i*2+1]
            result += self.cutlines[i].generate_1D_mask(i, height, y_width, swa1, swa2)
        return result


class GaugeSlicer:
    def __init__(self, gauge_file):
        f = open(gauge_file)
        self.header = f.readline()
        self.header = self.header.rstrip('\n\r')

        content = f.readlines()
        self.gauges = {}
        for line in content:
            gauge_name = line.split('\t')[0]
            self.gauges[gauge_name] = line

    def get_sliced(self, gauge_name, addition={}):
        line = self.gauges[gauge_name]
        line = line.rstrip('\n\r')
        sliced = "[gauge info]\nSiOx\n" + self.header
        for k in addition:
            sliced += '\t' + str(k)
            line += '\t' + str(addition[k])
        sliced += '\n' + line
        return sliced
