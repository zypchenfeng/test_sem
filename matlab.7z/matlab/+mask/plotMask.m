function [] = plotMask(mask, color, pitch)

    flag_3D = (pitch(2)>0) ;

    if flag_3D
        % Plot bottom face
        xcoord = mask.bottomPolygon(:,1) ; xcoord = max(xcoord,-pitch(1)/2) ; xcoord = min(xcoord,pitch(1)/2) ;
        ycoord = mask.bottomPolygon(:,2) ; ycoord = max(ycoord,-pitch(2)/2) ; ycoord = min(ycoord,pitch(2)/2) ;
        zcoord = mask.bottomPolygon(:,3) ;
        h = fill3(xcoord,ycoord,zcoord,color) ;
        h.FaceAlpha=0.3; 
        % Plot top face
        xcoord = mask.topPolygon(:,1) ; xcoord = max(xcoord,-pitch(1)/2) ; xcoord = min(xcoord,pitch(1)/2) ;
        ycoord = mask.topPolygon(:,2) ; ycoord = max(ycoord,-pitch(2)/2) ; ycoord = min(ycoord,pitch(2)/2) ;
        zcoord = mask.topPolygon(:,3) ;
        h = fill3(xcoord,ycoord,zcoord,color) ;
        h.FaceAlpha=0.3; 
        % Plot lateral faces
        nVertices = size(mask.bottomPolygon,1) ;
        for iVert = 1: nVertices
            xcoord = [ mask.bottomPolygon(iVert,1) mask.bottomPolygon( 1+mod(iVert,nVertices),1 ) ...
                        mask.topPolygon( 1+mod(iVert,nVertices),1 ) mask.topPolygon(iVert,1) ] ;
            ycoord = [ mask.bottomPolygon(iVert,2) mask.bottomPolygon( 1+mod(iVert,nVertices),2 ) ...
                        mask.topPolygon( 1+mod(iVert,nVertices),2 ) mask.topPolygon(iVert,2) ] ;
            zcoord = [ mask.bottomPolygon(iVert,3) mask.bottomPolygon( 1+mod(iVert,nVertices),3 ) ...
                        mask.topPolygon( 1+mod(iVert,nVertices),3 ) mask.topPolygon(iVert,3) ] ;
            xcoord = max(xcoord,-pitch(1)/2) ; xcoord = min(xcoord,pitch(1)/2) ;
            ycoord = max(ycoord,-pitch(2)/2) ; ycoord = min(ycoord,pitch(2)/2) ;
            h = fill3(xcoord,ycoord,zcoord,color) ;
            h.FaceAlpha=0.3;
        end
    else
        xcoord = [ min(mask.bottomPolygon(:,1)) ,max(mask.bottomPolygon(:,1)), ...
                    max(mask.topPolygon(:,1)), min(mask.topPolygon(:,1)) ] ;
        zcoord = [ min(mask.bottomPolygon(:,3)) ,min(mask.bottomPolygon(:,3)), ...
                    max(mask.topPolygon(:,3)), max(mask.topPolygon(:,3)) ] ;
        xcoord = max(xcoord,-pitch(1)/2) ; xcoord = min(xcoord,pitch(1)/2) ;
        h=fill( xcoord, zcoord, color);
        h.FaceAlpha=0.3;  
    end

end