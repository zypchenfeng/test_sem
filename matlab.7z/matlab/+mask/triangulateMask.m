function stack = triangulateMask(stack) 

%% Triangulate mask
% Assumptions:
%   a) the mask is a simple parallelepiped defined by a top and bottom polygon. 
%   b) top and bottom polygons are convex polygons with the same number of
%   edges
%   c) polygons are described as lists of counter clock wise ordered nodes
%   (when seen from "above", i.e. from an observer at z = Inf)
%   d) nodes defining top and bottom faces have the same ordering: there is an edge
%   between the n-th vertex of top polygon and the n-th vertex of bottom polygon

for iMask = 1: numel(stack.mask)  
    
    % Bottom polygon
    P = stack.mask{iMask}.bottomPolygon ;
    T = delaunay( P(:,1:2) ) ;
    mesh.nodes = P ;
    mesh.tri = T ;
    
    % Top polygon
    P = stack.mask{iMask}.topPolygon ;
    T = delaunay( P(:,1:2) ) ;
    offset = size(mesh.nodes,1) ;
    mesh.nodes = [ mesh.nodes ; P ] ;
    mesh.tri = [ mesh.tri ; T+offset ] ;
    
    % Lateral faces
    numberOfFaces = size(stack.mask{iMask}.bottomPolygon,1) ;
    for nFace = 1: numberOfFaces
        n0 = nFace ;
        n1 = mod(n0,numberOfFaces)+1 ;
        T = [ n0 n1 n1+numberOfFaces ;
            n0 n1+numberOfFaces n0+numberOfFaces ] ;
        mesh.tri = [ mesh.tri ; T ] ;
    end
    
    % Add mesh to the mask
    stack.mask{iMask}.mesh = mesh ;

end

% figure, set(groot, 'defaultAxesTickLabelInterpreter','latex'); set(groot, 'defaultLegendInterpreter','latex');
% hold on
% for iMask = 1: numel(stack.mask) 
%     trisurf(stack.mask{iMask}.mesh.tri,stack.mask{iMask}.mesh.nodes(:,1),stack.mask{iMask}.mesh.nodes(:,2),stack.mask{iMask}.mesh.nodes(:,3))
% end

end