function [flag_neutrals, flag_deposition] = enableSources(layers)

A = cell2mat(layers) ;
flag_neutrals = norm([A.etchRateH_n A.etchRateV_n])>0 ;
flag_deposition = norm([A.etchRateH_d A.etchRateV_d])>0 ;