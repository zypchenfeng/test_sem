function etchSettings = setEtchSettingsFromKLA()
% Etch settings from:
% Robert L. Jones, Chris A. Mack, Jeff D. Byers, 
% "Etch simulations for lithography engineers", 
% Proc. SPIE 4691, Optical Microlithography XV, (30 July 2002)

etchSettings.materials{1}.name = 'APEX-E' ;  % photoresist
etchSettings.materials{1}.etchRateH = -2.6 ;
etchSettings.materials{1}.etchRateV = 10.66 ;
etchSettings.materials{1}.facetingParameter = 0.5 ;
etchSettings.materials{1}.thickness = 740 ;

etchSettings.materials{4}.name = 'Brewer' ;  
etchSettings.materials{4}.etchRateH = -1.7 ;
etchSettings.materials{4}.etchRateV = 10.52 ;
etchSettings.materials{4}.facetingParameter = 0. ;
etchSettings.materials{4}.thickness = 63 ;

etchSettings.materials{3}.name = 'Polysilicon' ;  
etchSettings.materials{3}.etchRateH = 0. ;
etchSettings.materials{3}.etchRateV = 4.28 ;
etchSettings.materials{3}.facetingParameter = 0. ;
etchSettings.materials{3}.thickness = 230 ;

etchSettings.materials{2}.name = 'Oxide' ;  
etchSettings.materials{2}.etchRateH = 0. ;
etchSettings.materials{2}.etchRateV = 0. ;
etchSettings.materials{2}.facetingParameter = 0. ;
etchSettings.materials{2}.thickness = 100 ;

end