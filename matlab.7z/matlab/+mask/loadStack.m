function [profile, materials, numberOfLayers, steps] = loadStack(inputStack,materialsDB)

stack = loadD4Cstack(inputStack) ;
% [materialsDB] = mask.loadMaterials(inputMaterials) ;

% Add layers with constant parameters for the moment
% [ ER_V, ER_H, facetingParameter] = [10, 0, 0]
iMaterial = 0 ;
for iLayer = 1:numel(stack.layers)
    iMaterial = iMaterial + 1 ;
    foundMaterial = false ;
    for iM = 1: numel(materialsDB)
        if strcmpi( stack.layers(iLayer).name, materialsDB{iM}.name )
            foundMaterial = true ;
            materials{iMaterial}.name = stack.layers(iLayer).name ;
            materials{iMaterial}.thickness = stack.layers(iLayer).thickness ;
            materials{iMaterial}.etchRateV_i = materialsDB{iM}.etchRateV_i ;
            materials{iMaterial}.etchRateH_i = materialsDB{iM}.etchRateH_i ;
            materials{iMaterial}.facetingParameter_i = materialsDB{iM}.facetingParameter_i ;
            materials{iMaterial}.etchRateV_n = materialsDB{iM}.etchRateV_n ;
            materials{iMaterial}.etchRateH_n = materialsDB{iM}.etchRateH_n ;
            materials{iMaterial}.facetingParameter_n = materialsDB{iM}.facetingParameter_n ;     
            materials{iMaterial}.etchRateV_d = materialsDB{iM}.etchRateV_d ;
            materials{iMaterial}.etchRateH_d = materialsDB{iM}.etchRateH_d ;
            materials{iMaterial}.facetingParameter_d = materialsDB{iM}.facetingParameter_d ;
            break ;
        end
    end
    if ~foundMaterial
        sprintf('%s\n',['Material ' stack.layers(iLayer).name 'not found in materials database (assigning 0 etch rate)']) ;
        materials{iMaterial}.name = stack.layers(iLayer).name ;
        materials{iMaterial}.thickness = 0 ;
        materials{iMaterial}.etchRateV_i = 0 ;
        materials{iMaterial}.etchRateH_i = 0 ;
        materials{iMaterial}.facetingParameter_i = 0 ;
        materials{iMaterial}.etchRateV_n = 0 ;
        materials{iMaterial}.etchRateH_n = 0 ;
        materials{iMaterial}.facetingParameter_n = 0 ;
        materials{iMaterial}.etchRateV_d = 0 ;
        materials{iMaterial}.etchRateH_d = 0 ;
        materials{iMaterial}.facetingParameter_d = 0 ;
    end
end

% Remove suffix '_n' from material name in shapes
for iShape = 1: numel(stack.shapes)
    materialName = stack.shapes(iShape).name ;
    idx = strfind(materialName,'_') ;
    if ~isempty(idx)
        materialName = materialName(1:idx(end)-1) ;
    end
    stack.shapes(iShape).name = materialName ;
end

profile.mask = [] ;
for iShape = 1: numel(stack.shapes)
    foundMaterial = false ;
    % First search among active materials
    for iMaterial = 1: numel(materials)
        if strcmpi( stack.shapes(iShape).name, materials{iMaterial}.name )
            foundMaterial = true ;
            break
        end
    end
    % Search in materials DB
    if ~foundMaterial
        for iM = 1: numel(materialsDB)
            if strcmpi( stack.shapes(iShape).name, materialsDB{iM}.name )
                foundMaterial = true ;
                iMaterial = iMaterial + 1 ;
                materials{iMaterial}.name = stack.shapes(iShape).name ;
                materials{iMaterial}.thickness = 0 ;
                materials{iMaterial}.etchRateV_i = materialsDB{iM}.etchRateV_i ;
                materials{iMaterial}.etchRateH_i = materialsDB{iM}.etchRateH_i ;
                materials{iMaterial}.facetingParameter_i = materialsDB{iM}.facetingParameter_i ;
                materials{iMaterial}.etchRateV_n = materialsDB{iM}.etchRateV_n ;
                materials{iMaterial}.etchRateH_n = materialsDB{iM}.etchRateH_n ;
                materials{iMaterial}.facetingParameter_n = materialsDB{iM}.facetingParameter_n ;
                materials{iMaterial}.etchRateV_d = materialsDB{iM}.etchRateV_d ;
                materials{iMaterial}.etchRateH_d = materialsDB{iM}.etchRateH_d ;
                materials{iMaterial}.facetingParameter_d = materialsDB{iM}.facetingParameter_d ;     
                break ;
            end
        end    
    end
    % Add new material
    if ~foundMaterial
        sprintf('%s\n',['Material ' stack.shapes(iShape).name 'not found in materials database (assigning 0 etch rate)']) ;
        iMaterial = iMaterial + 1 ;
        materials{iMaterial}.name = stack.shapes(iShape).name ;
        materials{iMaterial}.thickness = 0 ;
        materials{iMaterial}.etchRateV_i = 0 ;
        materials{iMaterial}.etchRateH_i = 0 ;
        materials{iMaterial}.facetingParameter_i = 0 ;
        materials{iMaterial}.etchRateV_n = 0 ;
        materials{iMaterial}.etchRateH_n = 0 ;
        materials{iMaterial}.facetingParameter_n = 0 ;
        materials{iMaterial}.etchRateV_d = 0 ;
        materials{iMaterial}.etchRateH_d = 0 ;
        materials{iMaterial}.facetingParameter_d = 0 ;
    end
    profile.mask{iShape}.bottomPolygon = stack.shapes(iShape).slices{1} ;
    profile.mask{iShape}.topPolygon = stack.shapes(iShape).slices{2} ;
    profile.mask{iShape}.material = iMaterial ;
end

profile.pitch = stack.pitch ;
if isfield(stack,'CDinfo')
    profile.CDinfo = stack.CDinfo;
end

numberOfLayers = numel(stack.layers) ;

%% manually modify the thickness
materials{1, 2}.thickness = 40;
materials{1, 3}.thickness = 100;
materials{1, 4}.thickness = 30;
steps = [] ;
for iLayer = numberOfLayers:-1:1
    steps = [ steps; materials{iLayer}.thickness] ;
end
steps = [ 0 ; -cumsum(steps) - 6 ] ;                 % here the -6 is over-etch depth
end

function [stack] = loadD4Cstack(filename)

fileID = fopen(filename) ;

if fileID==-1
    sprintf('%s\n',['ERROR: can not open ' filename]) ;
    return
end

layers = [] ;
shapes = [] ;

iLine = 0; 
while ~feof(fileID)
    tline = fgetl(fileID);
    if isempty(tline)
        continue
    elseif strcmp(tline,'[pitch]')
        entityToRead = 1 ;
    elseif strcmp(tline,'[layers]')
        entityToRead = 2 ;
    elseif strcmp(tline,'[shapes]')
        entityToRead = 3 ;
    elseif strcmp(tline,'[gauge info]')  % added the gauge info reading function
        entityToRead = 4 ;
    else
        fseek(fileID,filePos,'bof') ;
    end
    switch entityToRead
        case 1
            pitch = readPitch(fileID) ; 
            pitch = 500;
            filePos = ftell(fileID) ;
        case 2
            aLayer = readLayer(fileID) ;
            if ~isempty(aLayer)
                if isempty(layers) || ~strcmpi(aLayer.name,layers(end).name)
                    layers = [ layers ; aLayer ] ;
                else
                    layers(end).thickness = layers(end).thickness + aLayer.thickness ;
                end
            end
            filePos = ftell(fileID) ;
        case 3
            aShape = readShape(fileID) ;
            if ~isempty(aShape)
                shapes = [ shapes ; aShape ] ;
            end
            filePos = ftell(fileID) ;
        case 4
            CDinfo = readCDinfo(fileID) ;
            filePos = ftell(fileID) ;
        otherwise
            sprintf('%s\n',['ERROR: unknown entity to read ' entityToRead]) ;
    end
end

fclose(fileID) ;

stack.pitch = pitch ;
stack.layers = layers ;
stack.shapes = shapes ;
if exist('CDinfo','var')
    stack.CDinfo = CDinfo ;
end

end

% =============================================================== 
%                   PRIVATE FUNCTIONS
% =============================================================== 

function pitch = readPitch(fileID) 

tline = fgetl(fileID);
pitch = str2num(tline) ;

end

function layer = readLayer(fileID) 

tline = fgetl(fileID);
if isempty(tline)
    layer = [] ;
    return;
end

data = textscan(tline,'%s') ;
name = cell2mat(data{1}(1)) ;
thickness = str2num(cell2mat(data{1}(2))) ;

layer.name = name ;
layer.thickness = thickness ;

end

function shape = readShape(fileID)

tline = fgetl(fileID);
if isempty(tline)
    shape = [] ;
    return ;
end

data = textscan(tline,'%s') ;
name = cell2mat(data{1}(1)) ;
Nz = str2num(cell2mat(data{1}(2))) ;
Nv = str2num(cell2mat(data{1}(3))) ;

tline = fgetl(fileID);
z = cell2mat(textscan(tline,'%f')) ;
for iz = 1: Nz
    tline = fgetl(fileID);
    xy = cell2mat(textscan(tline,'%f')) ;
    xy = reshape(xy,2,Nv)' ;
    slices{iz} = [ xy z(iz)*ones(Nv,1) ] ;
end

shape.name = name ;
shape.slices = slices ;

end

%% read in the CD information from the stack file

function [CDinfo] = readCDinfo(fileID)
tline = fgetl(fileID);
data = textscan(tline,'%s') ;
if size(tline, 2) < 20    
    name = cell2mat(data{1}(1)) ;
    CDinfo.material = name ;
else    
    CDinfo.name = cell2mat(data{1}(1));
    CDinfo.type = cell2mat(data{1}(2));
    CDinfo.tonesgn = str2double(data{1}(3));
    CDinfo.waferCD = str2double(data{1}(9));
    CDinfo.costwt = str2double(data{1}(10));
    CDinfo.EEB_Model_CD = str2double(data{1}(12));    
    CDinfo.ADI_Model_CD = str2double(data{1}(13));
    CDinfo.ILS = str2double(data{1}(14));
    CDinfo.ResistRatio = str2double(data{1}(15));
end
end