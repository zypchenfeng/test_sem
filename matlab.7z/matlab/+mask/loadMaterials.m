function [materials] = loadMaterials(filename)

% Number of etch steps per material is hardcoded here
numberOfSteps = 6 ;

fileID = fopen(filename) ;

if fileID==-1
    sprintf('%s\n',['ERROR: can not open ' filename]) ;
    return
end

% Read materials
materials = [] ;
iMaterial = 0 ;
while ~feof(fileID)
    iMaterial = iMaterial + 1 ;
    tline = fgetl(fileID);
    data = textscan(tline,'%s') ;
    name = cell2mat(data{1}(1)) ;
    materials{iMaterial}.name = name ;
    for iStep = 1: numberOfSteps
        tline = fgetl(fileID);
        data = sscanf(tline,'%f') ;
        numberOfCols = numel(data) ;
        if numberOfCols==6
            materials{iMaterial}.etchRateV_i(iStep) = data(1) ;
            materials{iMaterial}.etchRateH_i(iStep) = data(2) ;
            materials{iMaterial}.facetingParameter_i(iStep) = data(3) ;
            materials{iMaterial}.etchRateV_n(iStep) = data(4) ;
            materials{iMaterial}.etchRateH_n(iStep) = data(5) ;
            materials{iMaterial}.facetingParameter_n(iStep) = data(6) ;
            materials{iMaterial}.etchRateV_d(iStep) = 0 ;
            materials{iMaterial}.etchRateH_d(iStep) = 0 ;
            materials{iMaterial}.facetingParameter_d(iStep) = 0 ;
        elseif numberOfCols==9
            materials{iMaterial}.etchRateV_i(iStep) = data(1) ;
            materials{iMaterial}.etchRateH_i(iStep) = data(2) ;
            materials{iMaterial}.facetingParameter_i(iStep) = data(3) ;
            materials{iMaterial}.etchRateV_n(iStep) = data(4) ;
            materials{iMaterial}.etchRateH_n(iStep) = data(5) ;
            materials{iMaterial}.facetingParameter_n(iStep) = data(6) ;
            materials{iMaterial}.etchRateV_d(iStep) = data(7) ;
            materials{iMaterial}.etchRateH_d(iStep) = data(8) ;
            materials{iMaterial}.facetingParameter_d(iStep) = data(9) ;
        else
            sprintf('%s\n',['ERROR: number of parameters per row in ' filename ' must be 6 or 9']) ;
            return
        end
    end
end

fclose(fileID) ;

end