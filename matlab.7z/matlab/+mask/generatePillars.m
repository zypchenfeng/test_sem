function output = generatePillars(pitch, maskThickness, pillarLocation, pillarSize, sideWallAngle, defaultMaterial )

    if nargin<5
        sideWallAngle = 90 ;
    end
    
    if nargin < 6
        defaultMaterial = 1 ;
    end

    for iMask = 1: size(pillarLocation,1)
    
        bottomPolygon = [
            pillarLocation(iMask,1)-pillarSize(iMask,1)/2     pillarLocation(iMask,2)-pillarSize(iMask,2)/2     0 ;
            pillarLocation(iMask,1)+pillarSize(iMask,1)/2     pillarLocation(iMask,2)-pillarSize(iMask,2)/2     0 ;
            pillarLocation(iMask,1)+pillarSize(iMask,1)/2     pillarLocation(iMask,2)+pillarSize(iMask,2)/2     0 ;
            pillarLocation(iMask,1)-pillarSize(iMask,1)/2     pillarLocation(iMask,2)+pillarSize(iMask,2)/2     0 ;
            ] ;
        
        barycenter = mean(bottomPolygon) ;
        topPolygon = bottomPolygon - barycenter ;
        topPolygon = topPolygon - sign(topPolygon) .* ( .5/tand(sideWallAngle) * maskThickness ) ;
        topPolygon(:,3) = topPolygon(:,3) + maskThickness ;
        topPolygon = topPolygon + barycenter ;
        
        output{iMask}.bottomPolygon = bottomPolygon ;
        output{iMask}.topPolygon = topPolygon ;
        output{iMask}.material = defaultMaterial ;
    
    end
    
end