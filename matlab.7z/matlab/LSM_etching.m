%% LSM_etching.m
% 
% Description:
%    Example script for etching simulations through a level set approach

% Author : Alessandro Francavilla (AFRH)
%          ASML
% email  : alessandro.francavilla@asml.com  
% Website: 
%
% Implementation: February 2018 
% Revisions     : 2018-02-01, First implementation (AFRH)
% 

clear all;
close all;
% clc;

%% Simulation settings
inputgds_dir = './stacks/gds/';
inputgds = dir(strcat(inputgds_dir, '*.input'));
inputMaterials = './stacks/materials1.dat';   % filename of the input stack

% Etch source distributions
% Note: the angle where the Gaussian is centered is defined as seen from
% the observer (a 180deg difference in phi w.r.t. the angle seen from the source)
sourceSettings.ion.standardDeviation = 3 ;          % the standard deviation (=1*sigma) of ion angular distribution
sourceSettings.ion.theta0 = 0 ;                     % the theta angle identifying the center of the distribution
sourceSettings.ion.phi0 = 0 ;                       % the phi angle identifying the center of the distribution
sourceSettings.neutral.standardDeviation = 20 ;
sourceSettings.neutral.theta0 = 0 ;
sourceSettings.neutral.phi0 = 0 ;
materials = mask.loadMaterials(inputMaterials);

x = [85, 25, 3, 15, 35, -3];  % SOC step3 Ion verticle, Neutral verticle, horizontal, and SOC step4 Ion verticle, Neutral verticle, horizontal

flag_2D = true ;    % if true forces 2D simulation (the stack is considered invariant along the y direction)

% Time step settings
tMax = 4.2 ;     % Total simulation time (in seconds)

% Resolution settings
spatialResolution = 2 ;         % Arbitrary units, coherent with the stack representation (typically nm)

% results settings
save_gif = false ;          % set to true for storing a gif of the time evolution
results_folder = './Results/' ;  % Where to save results (gif animations)
Individual_gauge_path = strcat(results_folder, date, '_LSM_E3D.csv');
data_store = {'Gauge_Name,','type,', 'tone_sgn,', 'wafer_CD,', 'cost_wt,', 'EEB_CD,', 'ADIModelCD,', ...
        'ILS,', 'LSM_CD,', 'LSM_Error,', 'LSM_MSE,'};
    
% mse cost calculation
cost = 0;
    
tic
for i = 3
% parfor i = 1:size(inputgds, 1)    % if change to parfor, then capable of parallel computation
    inputStack = strcat(inputgds_dir, inputgds(i).name);   % filename of the input stack    
    
    %% Run etch simulation
    [X,Y,Z,phi, single_gauge_result] = levelSet.LSM_Etch3D(inputStack, materials, spatialResolution, sourceSettings, tMax, results_folder, flag_2D, save_gif) ;
    data_store = [data_store; single_gauge_result];
end
if size(data_store, 1) > 1
 for i = 2:size(data_store, 1)
     cost = cost + (str2double(strip(data_store{i, 10}, ',')))^2;
 end
 cost = cost/(size(data_store, 1)-1);
end

%% saving result
empt = [];
csvwrite(Individual_gauge_path, empt);
fid = fopen(Individual_gauge_path, 'w');
fprintf(fid, '%s', data_store{1, :});
if size(data_store, 1) > 1
 for i = 2:size(data_store, 1)
     fprintf(fid, '\n');
     fprintf(fid, '%s', data_store{i, :});
 end
end
fclose(fid);
toc